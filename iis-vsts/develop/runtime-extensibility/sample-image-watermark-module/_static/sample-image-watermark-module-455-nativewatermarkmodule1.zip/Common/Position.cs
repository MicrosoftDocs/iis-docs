//
// Copyright � Microsoft Corporation.  All rights reserved.
//

namespace WatermarkServer {
    using System;
    using Microsoft.Web.Administration;
    
    
    public enum Position {
        
        UpperLeft = 0,
        
        UpperRight = 1,
        
        LowerLeft = 2,
        
        LowerRight = 3,
        
        Center = 4,
        
        Stretch = 5,
        
        Tile = 6,
    }
}
