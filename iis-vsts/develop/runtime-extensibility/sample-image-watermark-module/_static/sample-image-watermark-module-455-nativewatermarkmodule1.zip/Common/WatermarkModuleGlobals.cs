﻿//
// Copyright © Microsoft Corporation.  All rights reserved.
//

using System;

namespace WatermarkServer
{
    public static class WatermarkModuleGlobals
    {
        public const int Enabled = 1;
        public const int WatermarkImage = 2;
        public const int Transparency = 3;
        public const int Position = 4;
        public const int IsLocked = 5;

        public const int Position_UpperLeft = 0;
        public const int Position_UpperRight = 1;
        public const int Position_LowerLeft = 2;
        public const int Position_LowerRight = 3;
        public const int Position_Center = 4;
    }
}
