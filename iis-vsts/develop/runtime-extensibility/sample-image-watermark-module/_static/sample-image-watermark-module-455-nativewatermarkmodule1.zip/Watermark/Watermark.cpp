//
// Copyright � Microsoft Corporation.  All rights reserved.
//


#include "stdafx.h"

#define MODULE_NAME "Watermark"

// Some defines for image types
#define IMAGE_JPEG 0
#define IMAGE_PNG 1
#define IMAGE_GIF 2

CHAR * g_arrImageMime[]  = { "image/jpeg", "image/png", "image/gif" };

HTTP_MODULE_ID CWatermarkModule::s_ModuleId = NULL;
IHttpServer* CWatermarkModule::s_HttpServer = NULL;


DWORD   g_dwEventNotifications = 0;

DWORD   g_dwPostEventNotifications = 0
            | RQ_EXECUTE_REQUEST_HANDLER
            ;

BOOL
WriteDebug(
    LPSTR   szFormat,
    ...
    );

HRESULT
WINAPI
RegisterModule(
    DWORD                           dwServerVersion,
    IHttpModuleRegistrationInfo *   pModuleInfo,
    IHttpServer *                   pGlobalInfo
    )
/*++

Routine Description:

  Required module entery point.  IIS calls into this function
  immediately after loading the module.  The module should then
  tell IIS which notifications it requires, and it can optionally
  do initialization tasks.

Arguments:

  dwServerVersion - The IIS version which is loading the module
  pModuleInfo     - Used for module registration tasks
  pGlobalInfo     - Server utilities available to module at init time

Returns:

  HRESULT

++*/
{
    CWatermarkModuleFactory *    pFactory;
    HRESULT             hr;

    CWatermarkModule::s_ModuleId = pModuleInfo->GetId();
    CWatermarkModule::s_HttpServer = pGlobalInfo;

    if ( g_dwEventNotifications || g_dwPostEventNotifications )
    {
        pFactory = new CWatermarkModuleFactory;

        if ( !pFactory )
        {
            return HRESULT_FROM_WIN32( ERROR_NOT_ENOUGH_MEMORY );
        }

        hr = pModuleInfo->SetRequestNotifications( pFactory,
                                                   g_dwEventNotifications,
                                                   g_dwPostEventNotifications );

        if ( FAILED( hr ) )
        {
            return hr;
        }
    }

    return S_OK;
}


REQUEST_NOTIFICATION_STATUS
CWatermarkModule::OnPostExecuteRequestHandler(
    IHttpContext *          pHttpContext,
    IHttpEventProvider *    pProvider
    )
{
    HRESULT hr = S_OK;
    IHttpResponse * pHttpResponse = NULL;
    PCSTR pszMimeType = NULL;
    CWatermarkMetaContext * pMetaContext = NULL;
    BOOL fProcessFile = FALSE;
    DWORD dwImageType = 0;

    //
    // Call the helper static helper method which retrieves the config
    // for this module at this path.
    //
    hr = CWatermarkMetaContext::GetParsedMetadata( pHttpContext, &pMetaContext );
    if ( FAILED( hr ) )
    {
        goto Finished;
    }

    // Bail if it's not enabled.
    if ( pMetaContext->IsEnabled() == FALSE )
    {
        goto Finished;
    }

    //
    // Get the "Content-Type" header and see if 
    // the response is a MIME type that we care about
    //
    pHttpResponse = pHttpContext->GetResponse();
    if ( pHttpResponse == NULL )
    {
        hr = E_FAIL;
        goto Finished;
    }

    pszMimeType = pHttpResponse->GetHeader( "Content-Type" );
    if ( pszMimeType == NULL || pszMimeType == "\0" )
    {
        // Get out, either not set or not empty
        goto Finished;
    }

    for (int i = 0 ; i < _countof( g_arrImageMime ); i++ )
    {
        if ( strcmp( pszMimeType, g_arrImageMime[i] ) == 0 )
        {
            dwImageType = i;
            fProcessFile = TRUE;
            break;
        }
    }

    // If it is, then watermark the image!
    if ( fProcessFile )
    {
        hr = WatermarkFile( pHttpContext, pHttpResponse, pMetaContext, dwImageType );
        if ( FAILED( hr ) )
        {
            goto Finished;
        }
    }

Finished:

    if ( FAILED( hr ) )
    {
        pProvider->SetErrorStatus( hr );

        return RQ_NOTIFICATION_FINISH_REQUEST;
    }

    return RQ_NOTIFICATION_CONTINUE;
}

HRESULT
CWatermarkModule::WatermarkFile( 
    IHttpContext *          pHttpContext,
    IHttpResponse * pHttpResponse,
    CWatermarkMetaContext * pMetaContext,
    DWORD dwImageType
    )
{
    HRESULT hr = S_OK;
    HANDLE hImageHandle = NULL;
    HTTP_RESPONSE * pRawResponse = NULL;
    USHORT usChunkCount = 0;
    HTTP_DATA_CHUNK * pDataChunks = NULL;
    WCHAR * pszHandlePath = NULL;
    DWORD dwPathLength = 0;
    DWORD dwRetLength = 0;
    PVOID pOutBuffer;
    DWORD cbBuffer;
    CImage * pMarkImage;

    // Get the raw HTTP response and retrieve the
    // response data.
    //
    // NOTE: For now, it only supports responses that come
    //       via a file handle.  
    //
    pRawResponse = pHttpResponse->GetRawHttpResponse();
    if ( pRawResponse == NULL )
    {
        hr = E_UNEXPECTED;
        goto Finished;
    }

    if ( pRawResponse->StatusCode != 200 )
    {
        // If we don't have a valid response, then skip this.
        goto Finished;
    }

    //
    // TODO: For now, we only deal with the file handle chunk type.
    //       Must add support for the other types.
    //
    usChunkCount = pRawResponse->EntityChunkCount;
    if ( usChunkCount != 1 )
    {
        goto Finished;
    }

    pDataChunks = pRawResponse->pEntityChunks;
    if ( pDataChunks == NULL )
    {
        hr = E_UNEXPECTED;
        goto Finished;
    }

    if ( pDataChunks->DataChunkType != HttpDataChunkFromFileHandle )
    {
        goto Finished;
    }
    
    //
    // TODO: We also ignore the byte range and assume whole file is image
    //
    hImageHandle = pDataChunks->FromFileHandle.FileHandle;
    if ( hImageHandle == NULL )
    {
        hr = E_UNEXPECTED;
        goto Finished;
    }

    //
    // Query the filesystem for the full path to the file.
    //
    dwRetLength = GetFinalPathNameByHandle( hImageHandle, pszHandlePath, dwPathLength, FILE_NAME_NORMALIZED );
    if ( dwRetLength == 0 )
    {
        hr = HRESULT_FROM_WIN32( GetLastError() );
        goto Finished;
    }

    dwPathLength = dwRetLength + 1;
    pszHandlePath = new WCHAR[ dwPathLength ];
    if ( pszHandlePath == NULL )
    {
        hr = E_OUTOFMEMORY;
        goto Finished;
    }

    dwRetLength = GetFinalPathNameByHandle( hImageHandle, pszHandlePath, dwPathLength, FILE_NAME_NORMALIZED );
    if ( dwRetLength == 0 )
    {
        hr = HRESULT_FROM_WIN32( GetLastError() );
        goto Finished;
    }
    if ( dwRetLength != ( dwPathLength - sizeof( WCHAR ) ) )
    {
        hr = E_UNEXPECTED;
        goto Finished;
    }

    // Ensure path is NULL terminated
    pszHandlePath[ dwPathLength - 1 ] = L'\0';

    // At this point, we have the file name of the original image.
    // Pass it off to the method that will do the watermark work.

    hr = pMetaContext->GetMarkImage( &pMarkImage );
    if ( FAILED( hr ) )
    {
        goto Finished;
    }
    
    hr = ProcessImage( pszHandlePath, 
                       pMetaContext->GetPosition(),
                       pMetaContext->GetTransparency(),
                       dwImageType,
                       pMarkImage,
                       &pOutBuffer,
                       &cbBuffer );
    if ( FAILED( hr ) )
    {
        goto Finished;
    }

    // Now go and change the data in the raw response
    // Note that we will not free or close any handles, since
    // it's assumed that the original handler for this data
    // will do the cleanup.  We're simply going to replace 
    // the stream with our image.

    pDataChunks->DataChunkType = HttpDataChunkFromMemory;
    pDataChunks->FromMemory.pBuffer = pOutBuffer; 
    pDataChunks->FromMemory.BufferLength = cbBuffer;

    //
    // TODO:  There's a serious issue here in that we don't change the eTag to 
    //        take into account the watermark stuff.  What this means is that
    //        if the watermarked image is cached on the client based upon
    //        the eTag and Last-Modified headers of the original image,
    //        AND changes are done to the watermark configuration (i.e.
    //        different image, position or transparency), unless the
    //        original image is also touched to make it seem it changed,
    //        any GET/HEAD requests would just return that the image is still current.
    //
    //        The easy fix would be to generate a new eTag based upon the watermark
    //        configuration at this level and the original eTag and replace the 
    //        header info.

Finished:

    if ( pszHandlePath != NULL )
    {
        delete [] pszHandlePath;
        pszHandlePath = NULL;
    }

    return hr;
}

HRESULT
CWatermarkModule::ProcessImage(
    PCWSTR pszImagePath,
    DWORD dwRenderPosition,
    DWORD dwTransparency,
    DWORD dwImageType,
    CImage * pMarkImage,
    PVOID * ppOutBuffer,
    DWORD * pcbBuffer
    )
{
    HRESULT hr = S_OK;
    IStream * pOutStream = NULL;
    HGLOBAL hOutData = NULL;
    STATSTG stat;
    DWORD dwDestX = 0;
    DWORD dwDestY = 0;
    DWORD dwWidth = 0;
    DWORD dwHeight = 0;
    DWORD dwImageCenterX = 0;
    DWORD dwImageCenterY = 0;
    CImage image;

    hr = image.Load( pszImagePath );
    if ( FAILED( hr ) )
    {
        goto Finished;
    }

    switch( dwRenderPosition )
    {
        case WATERMARK_POSITION_UPPER_LEFT:
            dwDestX = 0;
            dwDestY = 0;
            break;
        case WATERMARK_POSITION_UPPER_RIGHT:
            if ( pMarkImage->GetWidth() > image.GetWidth() )
            {
                dwDestX = 0;
            }
            else
            {
                dwDestX = image.GetWidth() - pMarkImage->GetWidth();
            }

            dwDestY = 0;
            break;
        case WATERMARK_POSITION_LOWER_LEFT:
            dwDestX = 0;

            if ( pMarkImage->GetHeight() > image.GetHeight() )
            {
                dwDestY = 0;
            }
            else
            {
                dwDestY = image.GetHeight() - pMarkImage->GetHeight();
            }
            break;
        case WATERMARK_POSITION_LOWER_RIGHT:
            if ( pMarkImage->GetWidth() > image.GetWidth() )
            {
                dwDestX = 0;
            }
            else
            {
                dwDestX = image.GetWidth() - pMarkImage->GetWidth();
            }

            if ( pMarkImage->GetHeight() > image.GetHeight() )
            {
                dwDestY = 0;
            }
            else
            {
                dwDestY = image.GetHeight() - pMarkImage->GetHeight();
            }
            break;
        case WATERMARK_POSITION_CENTER:
            dwImageCenterX = image.GetWidth() / 2;
            dwImageCenterY = image.GetHeight() / 2;

            if ( (DWORD) (pMarkImage->GetWidth() / 2) > dwImageCenterX )
            {
                dwDestX = 0;
            }
            else
            {
                dwDestX = dwImageCenterX - ( pMarkImage->GetWidth() / 2 );
            }

            if ( (DWORD) (pMarkImage->GetWidth() / 2) > dwImageCenterY )
            {
                dwDestY = 0;
            }
            else
            {
                dwDestY = dwImageCenterY - ( pMarkImage->GetHeight() / 2 );
            }
            break;
        case WATERMARK_POSITION_STRETCH:
            dwDestX = 0;
            dwDestY = 0;
            dwWidth = image.GetWidth();
            dwHeight = image.GetHeight();
            break;
        case WATERMARK_POSITION_TILE:
            hr = TileImage( pMarkImage, &image, dwTransparency );
            if ( FAILED( hr ) )
            {
                goto Finished;
            }
            break;
        default:
            break;
    }

    if ( dwRenderPosition != WATERMARK_POSITION_TILE )
    {
        if ( dwWidth == 0 )
        {
            if ( pMarkImage->GetWidth() > image.GetWidth() )
            {
                dwWidth = image.GetWidth();
            }
            else
            {
                dwWidth = pMarkImage->GetWidth();
            }
        }

        if ( dwHeight == 0 )
        {
            if ( pMarkImage->GetHeight() > image.GetHeight() )
            {
                dwHeight = image.GetHeight();
            }
            else
            {
                dwHeight = pMarkImage->GetHeight();
            }
        }
        hr = pMarkImage->AlphaBlend( image.GetDC(),
                                     dwDestX,
                                     dwDestY,
                                     dwWidth,
                                     dwHeight,
                                     0,
                                     0,
                                     pMarkImage->GetWidth(),
                                     pMarkImage->GetHeight(),
                                     (BYTE) ( ( 255 * dwTransparency ) / 100 ) );
        image.ReleaseDC();
        if ( FAILED( hr ) )
        {
            goto Finished;
        }
    }

    hr = CreateStreamOnHGlobal( NULL, TRUE, &pOutStream );
    if ( FAILED( hr ) )
    {
        goto Finished;
    }

    switch( dwImageType )
    {
        case IMAGE_JPEG:
            hr = image.Save( pOutStream, Gdiplus::ImageFormatJPEG );
            break;
        case IMAGE_PNG:
            hr = image.Save( pOutStream, Gdiplus::ImageFormatPNG );
            break;
        case IMAGE_GIF:
            hr = image.Save( pOutStream, Gdiplus::ImageFormatGIF );
            break;
        default:
            hr = E_UNEXPECTED;
            break;
    }
    if ( FAILED( hr ) )
    {
        goto Finished;
    }

    hr = pOutStream->Stat( &stat,
                           STATFLAG_NONAME );
    if ( FAILED( hr ) )
    {
        goto Finished;
    }

    _pOutStream = pOutStream;
    pOutStream = NULL;

    hr = GetHGlobalFromStream( _pOutStream, &hOutData );
    if ( FAILED( hr ) )
    {
        goto Finished;
    }

    _hOutData = hOutData;
    hOutData = NULL;

    *ppOutBuffer = GlobalLock( _hOutData );
    *pcbBuffer = (ULONG) stat.cbSize.LowPart;

Finished:

    if ( pOutStream != NULL )
    {
        pOutStream->Release();
        pOutStream = NULL;
    }

    return hr;
}

HRESULT
CWatermarkModule::TileImage(
    CImage * pMarkImage,
    CImage * pDestImage,
    DWORD dwTransparency
    )
{
    HRESULT hr = S_OK;
    DWORD dwDestX = 0;
    DWORD dwDestY = 0;
    DWORD dwWidth = 0;
    DWORD dwHeight = 0;
    BOOL fDone = FALSE;

    while ( ! fDone )
    {
        hr = pMarkImage->AlphaBlend( pDestImage->GetDC(),
                                     dwDestX,
                                     dwDestY,
                                     pMarkImage->GetWidth(),
                                     pMarkImage->GetHeight(),
                                     0,
                                     0,
                                     pMarkImage->GetWidth(),
                                     pMarkImage->GetHeight(),
                                     (BYTE) ( ( 255 * dwTransparency ) / 100 ) );
        pDestImage->ReleaseDC();
        if ( FAILED( hr ) )
        {
            goto Finished;
        }

        dwDestX += pMarkImage->GetWidth();

        if ( dwDestX >= (DWORD) pDestImage->GetWidth() )
        {
            dwDestY += pMarkImage->GetHeight();

            if ( dwDestY >= (DWORD) pDestImage->GetHeight() )
            {
                fDone = TRUE;
            }
            else
            {
                dwDestX = 0;
            }
        }
    }

Finished:

    return hr;
}


VOID
CWatermarkModule::Dispose(
    VOID
    )
{
    if ( _hOutData != NULL )
    {
        GlobalUnlock( _hOutData );
        _hOutData = NULL;
    }

    if ( _pOutStream != NULL )
    {
        _pOutStream->Release();
        _pOutStream = NULL;
    }

    delete this;

    return;
}

BOOL
WriteDebug(
    LPSTR   szFormat,
    ...
    )
{
    CHAR szOutputString[1024];
    CHAR szFormatInput[1024];
    va_list     args;

    va_start( args, szFormat );

    _vsnprintf_s( szFormatInput, sizeof( szFormatInput ), _TRUNCATE, szFormat, args );

    va_end( args );

    _snprintf_s( szOutputString, 
                  sizeof( szOutputString ), 
                  _TRUNCATE, 
                  "[%s %08x-%08x]: %s\r\n",
                  MODULE_NAME,
                  GetCurrentProcessId(),
                  GetCurrentThreadId(),
                  szFormatInput );

    OutputDebugStringA( szOutputString );

    return TRUE;
}


//virtual
HRESULT
CWatermarkModuleFactory::GetHttpModule(
    CHttpModule **      ppModule,
    IModuleAllocator * pAllocator
    )
{
    HRESULT hr = S_OK;
    CHttpModule * pModule = NULL;

    pModule = new (pAllocator) CWatermarkModule();
    if ( pModule == NULL )
    {
        hr = E_OUTOFMEMORY;
        goto Finished;
    }

    *ppModule = pModule;
    pModule = NULL;

Finished:

    if ( pModule != NULL )
    {
        pModule->Dispose();
        pModule = NULL;
    }

    return hr;
}

//virtual
VOID
CWatermarkModuleFactory::Terminate(
    VOID
    )
{
    delete this;

    return;
}
