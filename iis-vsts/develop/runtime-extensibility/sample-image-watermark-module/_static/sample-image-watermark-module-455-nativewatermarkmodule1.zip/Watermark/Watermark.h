//
// Copyright � Microsoft Corporation.  All rights reserved.
//

// The following ifdef block is the standard way of creating macros which make exporting 
// from a DLL simpler. All files within this DLL are compiled with the WATERMARK_EXPORTS
// symbol defined on the command line. this symbol should not be defined on any project
// that uses this DLL. This way any other project whose source files include this file see 
// WATERMARK_API functions as being imported from a DLL, whereas this DLL sees symbols
// defined with this macro as being exported.
#ifdef WATERMARK_EXPORTS
#define WATERMARK_API __declspec(dllexport)
#else
#define WATERMARK_API __declspec(dllimport)
#endif

// Forward declaration
class CWatermarkMetaContext;

class CWatermarkModule : public CHttpModule
{
    //
    // Some static methods to store and obtain global information
    //

public:
    static
    HTTP_MODULE_ID
    GetModuleId() { return s_ModuleId; }

    static
    IHttpServer *
    GetGlobalHttpServer() { return s_HttpServer; }

    static HTTP_MODULE_ID s_ModuleId;
    static IHttpServer* s_HttpServer;

    //
    // Instance implementation for this module
    //
public:
    CWatermarkModule() : 
      _pOutStream( NULL ),
      _hOutData( NULL )
    { 
    }

    ~CWatermarkModule()
    {
        Dispose();
    }

    VOID *
    operator new(
        size_t size,
        VOID * pPlacement
        )
    {
        IModuleAllocator * pAllocator = (IModuleAllocator *) pPlacement;
        return pAllocator->AllocateMemory( (DWORD) size);
    }

    VOID
    operator delete(
        VOID* pModule
        )
    {
        // Because we used the IModuleAllocator, don't worry about deleting.
        // It will be handled automatically once request is completed.
    }

    virtual
    REQUEST_NOTIFICATION_STATUS
    OnPostExecuteRequestHandler(
        IHttpContext *          pHttpContext,
        IHttpEventProvider *    pProvider
        );

    virtual
    VOID
    Dispose(
        VOID
        );

private:
    HRESULT
    WatermarkFile( 
        IHttpContext *          pHttpContext,
        IHttpResponse * pHttpResponse,
        CWatermarkMetaContext * pMetaContext,
        DWORD dwImageType
        );

    HRESULT
    ProcessImage(
        PCWSTR pszImagePath,
        DWORD dwRenderPosition,
        DWORD dwTransparency,
        DWORD dwImageType,
        CImage * pMarkImage,
        PVOID * pOutBuffer,
        DWORD * pcbBuffer
        );

    HRESULT
    TileImage(
        CImage * pMarkImage,
        CImage * pDestImage,
        DWORD dwTransparency
        );
private:

    IStream * _pOutStream;
    HGLOBAL _hOutData;
};


class CWatermarkModuleFactory : public IHttpModuleFactory
{
public:

    virtual
    HRESULT
    GetHttpModule(
        CHttpModule **      ppModule,
        IModuleAllocator * pAllocator
        );

    virtual
    VOID
    Terminate(
        VOID
        );
};
