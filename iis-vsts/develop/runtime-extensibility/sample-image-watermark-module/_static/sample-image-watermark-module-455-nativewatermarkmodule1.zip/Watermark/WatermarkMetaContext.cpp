//
// Copyright � Microsoft Corporation.  All rights reserved.
//

#include "StdAfx.h"

class CWatermarkModule;

CWatermarkMetaContext::CWatermarkMetaContext(void) :
    _fEnabled( FALSE ),
    _bstrMarkFile( NULL ),
    _dwTransparency( 50 ),
    _dwPosition( 3 ),
    _pMarkImage( NULL )
{
}

CWatermarkMetaContext::~CWatermarkMetaContext(void)
{
    if ( _bstrMarkFile != NULL )
    {
        SysFreeString( _bstrMarkFile );
        _bstrMarkFile = NULL;
    }

    if ( _pMarkImage != NULL )
    {
        delete _pMarkImage;
        _pMarkImage = NULL;
    }
}

HRESULT 
GetDWORDProperty(
    IAppHostElement * pSection,
    PCWSTR pszPropertyName,
    DWORD * pdwValue
    )
{    
    HRESULT            hr = S_OK;
    IAppHostProperty * pProperty = NULL;
    BSTR               bstrName = NULL;
    VARIANT            varValue;

    VariantInit( &varValue );

    bstrName = SysAllocString( pszPropertyName );
    if ( bstrName == NULL )
    {
        hr = HRESULT_FROM_WIN32( ERROR_NOT_ENOUGH_MEMORY );
        goto Finished;
    }

    hr = pSection->GetPropertyByName( bstrName,
                                      &pProperty );
    if ( FAILED ( hr ) )  
    {
        goto Finished;
    }

    hr = pProperty->get_Value( &varValue );
    if ( FAILED ( hr ) )
    {
         goto Finished;
    }

    hr = VariantChangeType( &varValue, &varValue, 0, VT_UI4 );
    if ( FAILED ( hr ) )
    {
         goto Finished;
    }

    // extract the value
    *pdwValue = varValue.ulVal;
    
Finished:

    VariantClear( &varValue );

    if ( pProperty != NULL )
    {
        pProperty->Release();
        pProperty = NULL;
    }

    if ( bstrName != NULL )
    {
        SysFreeString( bstrName );
        bstrName = NULL;
    }

    return hr;
}

HRESULT 
GetStringProperty(
    IAppHostElement * pSection,
    PCWSTR pszPropertyName,
    BSTR * pbstrValue
    )
{
    HRESULT hr = S_OK;
    BSTR    bstrPropertyName = NULL;
    IAppHostProperty * pProperty = NULL;

    bstrPropertyName = SysAllocString( pszPropertyName );
    if ( bstrPropertyName == NULL )
    {
        hr = HRESULT_FROM_WIN32( ERROR_NOT_ENOUGH_MEMORY );
        goto Finished;
    }

    // Now ask for the property and if it succeeds it is returned directly back.
    hr = pSection->GetPropertyByName( bstrPropertyName, &pProperty );
    if ( FAILED ( hr ) )
    {
       goto Finished;
    }

    // Finally we can get the property, it will still need to be
    // freed with SysFreeString.
    hr = pProperty->get_StringValue( pbstrValue );
    if ( FAILED ( hr ) )
    {
       goto Finished;
    }
    
Finished:

    if ( bstrPropertyName != NULL )
    {
        SysFreeString( bstrPropertyName );
        bstrPropertyName = NULL;
    }

    if ( pProperty != NULL )
    {
        pProperty->Release();
        pProperty = NULL;
    }

    return hr;    
} 


HRESULT
CWatermarkMetaContext::Initialize( 
    IHttpContext * pContext )
{
    HRESULT hr = S_OK;
    IAppHostAdminManager * pAdminManager = NULL;
    BSTR bstrSectionName = NULL;
    BSTR bstrPath = NULL;
    IAppHostElement * pWatermarkSection = NULL;

    if ( ! InitializeCriticalSectionAndSpinCount( &_csLock, 1000 ) )
    {
        hr = HRESULT_FROM_WIN32( GetLastError() );
        goto Finished;
    }

    pAdminManager = (CWatermarkModule::GetGlobalHttpServer())->GetAdminManager();

    bstrSectionName = SysAllocString( L"system.webServer/watermark" );
    if ( bstrSectionName == NULL )
    {
        hr = E_OUTOFMEMORY;
        goto Finished;
    }

    bstrPath = SysAllocString( pContext->GetMetadata()->GetMetaPath() );
    if ( bstrPath == NULL )
    {
        hr = E_OUTOFMEMORY;
        goto Finished;
    }

    hr = pAdminManager->GetAdminSection( bstrSectionName,
                                         bstrPath,
                                         &pWatermarkSection
                                        );
    if ( FAILED( hr ) )
    {
        goto Finished;
    }

    hr = GetDWORDProperty( pWatermarkSection,
                           L"enabled",
                           (DWORD *) &_fEnabled );
    if ( FAILED( hr ) )
    {
        goto Finished;
    }

    hr = GetDWORDProperty( pWatermarkSection,
                           L"transparency",
                           &_dwTransparency );
    if ( FAILED( hr ) )
    {
        goto Finished;
    }

    hr = GetDWORDProperty( pWatermarkSection,
                           L"position",
                           &_dwPosition );
    if ( FAILED( hr ) )
    {
        goto Finished;
    }

    hr = GetStringProperty( pWatermarkSection,
                            L"watermarkImage",
                            &_bstrMarkFile );
    if ( FAILED( hr ) )
    {
        goto Finished;
    }


Finished:

    if ( bstrSectionName != NULL )
    {
        SysFreeString( bstrSectionName );
        bstrSectionName = NULL;
    }

    if ( bstrPath != NULL )
    {
        SysFreeString( bstrPath );
        bstrPath = NULL;
    }

    if ( pWatermarkSection != NULL )
    {
        pWatermarkSection->Release();
        pWatermarkSection = NULL;
    }

    return hr;
}

HRESULT
CWatermarkMetaContext::GetMarkImage(
    CImage ** ppImage
    )
{
    HRESULT hr = S_OK;
    BOOL fLocked = FALSE;
    CImage * pImage = NULL;
    CImage * pPrevImage = NULL;

    if ( _pMarkImage != NULL )
    {
        *ppImage = _pMarkImage;
        return S_OK;
    }
    
    EnterCriticalSection( &_csLock );
    fLocked = TRUE;

    if ( _pMarkImage != NULL )
    {
        *ppImage = _pMarkImage;
        goto Finished;
    }

    pImage = new CImage;
    if ( pImage == NULL )
    {
        hr = E_OUTOFMEMORY;
        goto Finished;
    }

    hr = pImage->Load( (PCWSTR) _bstrMarkFile );
    if ( FAILED ( hr ) )
    {
        goto Finished;
    }

    _pMarkImage = pImage;

    LeaveCriticalSection( &_csLock );
    fLocked = FALSE;

    *ppImage = _pMarkImage;

Finished:

    if ( fLocked )
    {
        LeaveCriticalSection( &_csLock );
        fLocked = FALSE;
    }

    return hr;
}

//virtual
VOID
CWatermarkMetaContext::CleanupStoredContext( 
    )
{
    delete this;
}


//static
HRESULT
CWatermarkMetaContext::GetParsedMetadata(
    IN IHttpContext * pContext,
    OUT CWatermarkMetaContext ** ppMetaContext 
    )
{
    HRESULT hr = S_OK;
    IHttpModuleContextContainer * pContainer = NULL;
    CWatermarkMetaContext * pMetaContext = NULL;

    pContainer = pContext->GetMetadata()->GetModuleContextContainer();

    pMetaContext = (CWatermarkMetaContext *) pContainer->GetModuleContext( CWatermarkModule::GetModuleId() );
    if ( pMetaContext != NULL )
    {
        *ppMetaContext = pMetaContext;
        return S_OK;
    }

    pMetaContext = new CWatermarkMetaContext();
    if ( pMetaContext == NULL )
    {
        hr = E_OUTOFMEMORY;
        goto Finished;
    }

    hr = pMetaContext->Initialize( pContext );
    if ( FAILED( hr ) )
    {
        goto Finished;
    }

    hr = pContainer->SetModuleContext( pMetaContext,
                                       CWatermarkModule::GetModuleId() );
    if ( FAILED( hr ) )
    {
        pMetaContext->CleanupStoredContext();
        pMetaContext = NULL;

        // Check and see if it's ERROR_ALREADY_ASSIGNED, in which case
        // we should retrieve that object and return it
        if ( hr == HRESULT_FROM_WIN32( ERROR_ALREADY_ASSIGNED ) )
        {
            *ppMetaContext = (CWatermarkMetaContext *) pContainer->GetModuleContext( CWatermarkModule::GetModuleId() );
            hr = S_OK;
            goto Finished;
        }
    }

    *ppMetaContext = pMetaContext;

Finished:

    return hr;
}
