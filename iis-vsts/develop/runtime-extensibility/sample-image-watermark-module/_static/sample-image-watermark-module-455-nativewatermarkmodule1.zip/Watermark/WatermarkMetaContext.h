//
// Copyright � Microsoft Corporation.  All rights reserved.
//

#pragma once

// Watermark render positions (matches description from watermark.xml schema)
#define WATERMARK_POSITION_UPPER_LEFT 0
#define WATERMARK_POSITION_UPPER_RIGHT 1
#define WATERMARK_POSITION_LOWER_LEFT 2
#define WATERMARK_POSITION_LOWER_RIGHT 3
#define WATERMARK_POSITION_CENTER 4
#define WATERMARK_POSITION_STRETCH 5
#define WATERMARK_POSITION_TILE 6

class CWatermarkMetaContext: IHttpStoredContext
{
public:
    static
    HRESULT
    GetParsedMetadata(
        IN IHttpContext * pContext,
        OUT CWatermarkMetaContext ** ppMetaContext 
        );

public:
    CWatermarkMetaContext(void);

    ~CWatermarkMetaContext(void);

    virtual
    VOID
    CleanupStoredContext( 
        );

    BOOL
    IsEnabled()
    {
        return _fEnabled;
    }

    HRESULT
    GetMarkImage(
        CImage ** ppImage
        );

    PCWSTR
    GetMarkFilename()
    {
        return _bstrMarkFile;
    }

    DWORD
    GetTransparency()
    {
        return _dwTransparency;
    }

    DWORD
    GetPosition()
    {
        return _dwPosition;
    }

    HRESULT
    Initialize( 
        IHttpContext * pContext 
        );


private:
    BOOL _fEnabled;

    BSTR _bstrMarkFile;

    DWORD _dwTransparency;

    DWORD _dwPosition;

    CRITICAL_SECTION _csLock;

    CImage * _pMarkImage;
};
