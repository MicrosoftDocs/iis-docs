//
// Copyright � Microsoft Corporation.  All rights reserved.
//


#pragma once

#include "targetver.h"

#define WIN32_LEAN_AND_MEAN             // Exclude rarely-used stuff from Windows headers
#define _WINSOCKAPI_
#define _CRT_SECURE_NO_DEPRECATE

// Windows Header Files:
#include <sal.h>
#include <stdio.h>
#include <windows.h>
#include <httpserv.h>
#include <atlimage.h>

// TODO: reference additional headers your program requires here
#include "Watermark.h"
#include "WatermarkMetaContext.h"