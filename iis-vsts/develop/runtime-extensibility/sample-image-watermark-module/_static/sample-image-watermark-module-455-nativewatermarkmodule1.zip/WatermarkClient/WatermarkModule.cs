﻿//
// Copyright © Microsoft Corporation.  All rights reserved.
//

using System;
using System.Collections.Generic;
using System.Text;
using System.Diagnostics;
using System.Drawing;
using Microsoft.Web.Management.Client;
using Microsoft.Web.Management.Client.Win32;
using Microsoft.Web.Management.Server;

namespace WatermarkClient
{
    public sealed class WatermarkModule : Module
    {
        protected override void Initialize(IServiceProvider serviceProvider, ModuleInfo moduleInfo)
        {
            base.Initialize(serviceProvider, moduleInfo);

            IControlPanel controlPanel = (IControlPanel)serviceProvider.GetService(typeof(IControlPanel));
            Debug.Assert(controlPanel != null, "Couldn't get IControlPanel");

            Bitmap featureSmallImage = Resources.WatermarkFeature16;
            Bitmap featureImage = Resources.WatermarkFeature32;

            ModulePageInfo watermarkPage =
                new ModulePageInfo(this, typeof(WatermarkPage), Resources.WatermarkTitle,
                Resources.WatermarkDescription, featureSmallImage, featureImage, Resources.WatermarkLongDescription);

            controlPanel.RegisterPage(ControlPanelCategoryInfo.CommonHttp, watermarkPage);
            controlPanel.RegisterPage(ControlPanelCategoryInfo.Iis, watermarkPage);
        }

        protected override bool IsPageEnabled(ModulePageInfo pageInfo)
        {
            Connection connection = (Connection)GetService(typeof(Connection));

            ICollection<string> currentBindingProtocols =
                connection.ConfigurationPath.GetBindingProtocols(this);

            if ( connection.ConfigurationPath.PathType != ConfigurationPathType.Server &&
                ( ! currentBindingProtocols.Contains("http") ) &&
                ( ! currentBindingProtocols.Contains("https") ) )
            {
                return false;
            }

            return base.IsPageEnabled(pageInfo);
        }
    }
}
