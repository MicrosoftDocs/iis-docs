﻿//
// Copyright © Microsoft Corporation.  All rights reserved.
//

using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.Web.Management.Server;
using Microsoft.Web.Management.Client;

namespace WatermarkClient
{
    public sealed class WatermarkModuleProxy : ModuleServiceProxy
    {
        public WatermarkModuleProxy()
        {
        }

        public PropertyBag GetWatermarkSettings()
        {
            return (PropertyBag)this.Invoke("GetWatermarkSettings");
        }

        public void UpdateWatermarkSettings(PropertyBag updatedSettings)
        {
            Invoke("UpdateWatermarkSettings", updatedSettings);
        }
    }
}
