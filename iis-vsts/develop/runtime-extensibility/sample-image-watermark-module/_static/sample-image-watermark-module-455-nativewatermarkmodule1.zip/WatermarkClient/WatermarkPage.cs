﻿//
// Copyright © Microsoft Corporation.  All rights reserved.
//

using System;
using System.Collections.Generic;
using System.Text;
using System.Drawing;
using System.Windows.Forms;
using Microsoft.Web.Management.Client;
using Microsoft.Web.Management.Client.Win32;
using Microsoft.Web.Management.Server;
using WatermarkServer;

namespace WatermarkClient
{
    [ModulePageIdentifier("469FE578-0D15-47fa-8A24-D4F5CDFE8E0A")]
    public sealed class WatermarkPage : ModuleDialogPage
    {
        private WatermarkModuleProxy _serviceProxy;
        internal WatermarkPageControl _pageControl = null;
        internal PropertyBag _bag = null;
        bool _hasChanges = false;
        bool _readOnly = false;

        public WatermarkPage()
        {
            InitializeComponent();
        }

        protected override bool ApplyChanges()
        {
            bool appliedChanges = false;

            try
            {
                Cursor.Current = Cursors.WaitCursor;

                _pageControl.GetValues(_bag);

                _serviceProxy.UpdateWatermarkSettings(_bag);

                _pageControl.ResetHasChanges();

                _hasChanges = false;
                appliedChanges = true;
            }
            catch (Exception ex)
            {
                DisplayErrorMessage(ex, Resources.ResourceManager);
            }
            finally
            {
                Cursor.Current = Cursors.Default;
                Update();
            }

            return appliedChanges;
        }

        protected override bool CanApplyChanges
        {
            get 
            { 
                return _hasChanges; 
            }
        }

        protected override bool HasChanges
        {
            get
            {
                return _hasChanges;
            }
        }

        internal void SetHasChanges(bool hasChanges)
        {
            _hasChanges = hasChanges;
            Update();
        }

        protected override void CancelChanges()
        {
            // Do nothing
        }

        private void InitializeComponent()
        {
            _pageControl = new WatermarkPageControl( this );

            this.Controls.Add(_pageControl);
        }

        protected override bool ReadOnly
        {
            get
            {
                return _readOnly;
            }
        }

        protected override void OnActivated(bool initialActivation)
        {

            base.OnActivated(initialActivation);

            if (initialActivation)
            {
                _serviceProxy = (WatermarkModuleProxy)CreateProxy(typeof(WatermarkModuleProxy));

                _bag = _serviceProxy.GetWatermarkSettings();

                if (_bag != null)
                {
                    _readOnly = (bool)_bag[WatermarkModuleGlobals.IsLocked];
                    _pageControl.SetValues(_bag);
                }
            }
        }
    }
}
