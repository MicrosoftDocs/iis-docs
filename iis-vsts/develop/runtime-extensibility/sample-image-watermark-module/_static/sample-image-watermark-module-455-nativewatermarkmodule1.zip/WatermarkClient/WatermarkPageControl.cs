﻿//
// Copyright © Microsoft Corporation.  All rights reserved.
//

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Text;
using System.Windows.Forms;
using Microsoft.Web.Management.Server;
using WatermarkServer;

namespace WatermarkClient
{
    public partial class WatermarkPageControl : UserControl
    {
        private WatermarkPage _page;

        public WatermarkPageControl(WatermarkPage page)
        {
            _page = page;
            InitializeComponent();
            _positionComboBox.DataSource = Enum.GetValues(typeof(WatermarkServer.Position));
            _transparencyTrackBar.SetRange(0, 100);
        }

        public void SetValues(PropertyBag bag)
        {
            bool enabled;

            enabled = (bool) bag[WatermarkModuleGlobals.Enabled];
            _enabledCheckBox.Checked = enabled;

            _watermarkFile.Text = (string) bag[WatermarkModuleGlobals.WatermarkImage];
            _transparencyTrackBar.Value = (int) bag[WatermarkModuleGlobals.Transparency];
            _transparencyTextBox.Text = _transparencyTrackBar.Value.ToString();

            _positionComboBox.SelectedItem = (Position) bag[WatermarkModuleGlobals.Position];

            SetControlsEnabled( enabled );
        }

        public void GetValues(PropertyBag bag)
        {
            bag[WatermarkModuleGlobals.Enabled] = _enabledCheckBox.Checked;

            if (_enabledCheckBox.Checked)
            {
                bag[WatermarkModuleGlobals.WatermarkImage] = _watermarkFile.Text;
                bag[WatermarkModuleGlobals.Transparency] = _transparencyTrackBar.Value;
                bag[WatermarkModuleGlobals.Position] = (Position)_positionComboBox.SelectedValue;
            }

        }


        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this._enabledCheckBox = new System.Windows.Forms.CheckBox();
            this._watermarkFile = new System.Windows.Forms.TextBox();
            this._openFileDialog = new System.Windows.Forms.OpenFileDialog();
            this._transparencyTrackBar = new System.Windows.Forms.TrackBar();
            this._watermarkGroupBox = new System.Windows.Forms.GroupBox();
            this._transparencyTextBox = new System.Windows.Forms.TextBox();
            this._imageFileButton = new System.Windows.Forms.Button();
            this._transparencyLabel = new System.Windows.Forms.Label();
            this._positionComboBox = new System.Windows.Forms.ComboBox();
            this._positionLabel = new System.Windows.Forms.Label();
            this._watermarkLabel = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this._transparencyTrackBar)).BeginInit();
            this._watermarkGroupBox.SuspendLayout();
            this.SuspendLayout();
            // 
            // _enabledCheckBox
            // 
            this._enabledCheckBox.AutoSize = true;
            this._enabledCheckBox.Location = new System.Drawing.Point(25, 59);
            this._enabledCheckBox.Name = "_enabledCheckBox";
            this._enabledCheckBox.Size = new System.Drawing.Size(65, 17);
            this._enabledCheckBox.TabIndex = 0;
            this._enabledCheckBox.Text = global::WatermarkClient.Resources.Enabled;
            this._enabledCheckBox.UseVisualStyleBackColor = true;
            this._enabledCheckBox.CheckStateChanged += new System.EventHandler(this.EnableCheckedStateChanged);
            // 
            // _watermarkFile
            // 
            this._watermarkFile.Location = new System.Drawing.Point(31, 42);
            this._watermarkFile.Name = "_watermarkFile";
            this._watermarkFile.Size = new System.Drawing.Size(313, 20);
            this._watermarkFile.TabIndex = 1;
            this._watermarkFile.TextChanged += new System.EventHandler(this.FileTextChanged);
            // 
            // _openFileDialog
            // 
            this._openFileDialog.FileOk += new System.ComponentModel.CancelEventHandler(this.FileSelected);
            // 
            // _transparencyTrackBar
            // 
            this._transparencyTrackBar.Location = new System.Drawing.Point(31, 145);
            this._transparencyTrackBar.Maximum = 100;
            this._transparencyTrackBar.Name = "_transparencyTrackBar";
            this._transparencyTrackBar.Size = new System.Drawing.Size(218, 42);
            this._transparencyTrackBar.TabIndex = 3;
            this._transparencyTrackBar.ValueChanged += new System.EventHandler(this.BarValueChanged);
            // 
            // _watermarkGroupBox
            // 
            this._watermarkGroupBox.Controls.Add(this._transparencyTextBox);
            this._watermarkGroupBox.Controls.Add(this._imageFileButton);
            this._watermarkGroupBox.Controls.Add(this._transparencyLabel);
            this._watermarkGroupBox.Controls.Add(this._positionComboBox);
            this._watermarkGroupBox.Controls.Add(this._positionLabel);
            this._watermarkGroupBox.Controls.Add(this._watermarkLabel);
            this._watermarkGroupBox.Controls.Add(this._transparencyTrackBar);
            this._watermarkGroupBox.Controls.Add(this._watermarkFile);
            this._watermarkGroupBox.Location = new System.Drawing.Point(23, 89);
            this._watermarkGroupBox.Name = "_watermarkGroupBox";
            this._watermarkGroupBox.Size = new System.Drawing.Size(411, 202);
            this._watermarkGroupBox.TabIndex = 4;
            this._watermarkGroupBox.TabStop = false;
            this._watermarkGroupBox.Text = "Watermark";
            // 
            // _transparencyTextBox
            // 
            this._transparencyTextBox.Location = new System.Drawing.Point(255, 145);
            this._transparencyTextBox.Name = "_transparencyTextBox";
            this._transparencyTextBox.Size = new System.Drawing.Size(40, 20);
            this._transparencyTextBox.TabIndex = 10;
            this._transparencyTextBox.TextChanged += new System.EventHandler(this.TransparencyTextChanged);
            // 
            // _imageFileButton
            // 
            this._imageFileButton.Location = new System.Drawing.Point(350, 42);
            this._imageFileButton.Name = "_imageFileButton";
            this._imageFileButton.Size = new System.Drawing.Size(28, 20);
            this._imageFileButton.TabIndex = 9;
            this._imageFileButton.Text = "...";
            this._imageFileButton.UseVisualStyleBackColor = true;
            this._imageFileButton.Click += new System.EventHandler(this.FileButtonClicked);
            // 
            // _transparencyLabel
            // 
            this._transparencyLabel.AutoSize = true;
            this._transparencyLabel.Location = new System.Drawing.Point(31, 126);
            this._transparencyLabel.Name = "_transparencyLabel";
            this._transparencyLabel.Size = new System.Drawing.Size(75, 13);
            this._transparencyLabel.TabIndex = 8;
            this._transparencyLabel.Text = "Transparency:";
            // 
            // _positionComboBox
            // 
            this._positionComboBox.FormattingEnabled = true;
            this._positionComboBox.Location = new System.Drawing.Point(31, 90);
            this._positionComboBox.Name = "_positionComboBox";
            this._positionComboBox.Size = new System.Drawing.Size(347, 21);
            this._positionComboBox.TabIndex = 7;
            this._positionComboBox.SelectedValueChanged += new System.EventHandler(this.PositionChanged);
            // 
            // _positionLabel
            // 
            this._positionLabel.AutoSize = true;
            this._positionLabel.Location = new System.Drawing.Point(28, 74);
            this._positionLabel.Name = "_positionLabel";
            this._positionLabel.Size = new System.Drawing.Size(47, 13);
            this._positionLabel.TabIndex = 6;
            this._positionLabel.Text = "Position:";
            // 
            // _watermarkLabel
            // 
            this._watermarkLabel.AutoSize = true;
            this._watermarkLabel.Location = new System.Drawing.Point(28, 26);
            this._watermarkLabel.Name = "_watermarkLabel";
            this._watermarkLabel.Size = new System.Drawing.Size(94, 13);
            this._watermarkLabel.TabIndex = 5;
            this._watermarkLabel.Text = "Watermark Image:";
            // 
            // WatermarkPageControl
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this._watermarkGroupBox);
            this.Controls.Add(this._enabledCheckBox);
            this.Name = "WatermarkPageControl";
            this.Size = new System.Drawing.Size(460, 379);
            ((System.ComponentModel.ISupportInitialize)(this._transparencyTrackBar)).EndInit();
            this._watermarkGroupBox.ResumeLayout(false);
            this._watermarkGroupBox.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.CheckBox _enabledCheckBox;
        private System.Windows.Forms.TextBox _watermarkFile;
        private System.Windows.Forms.OpenFileDialog _openFileDialog;
        private System.Windows.Forms.TrackBar _transparencyTrackBar;
        private System.Windows.Forms.GroupBox _watermarkGroupBox;
        private System.Windows.Forms.Label _watermarkLabel;
        private System.Windows.Forms.ComboBox _positionComboBox;
        private System.Windows.Forms.Label _positionLabel;
        private System.Windows.Forms.Label _transparencyLabel;
        private System.Windows.Forms.Button _imageFileButton;
        private System.Windows.Forms.TextBox _transparencyTextBox;

        bool _enabledChanged = false;
        bool _watermarkFileChanged = false;
        bool _transparencyChanged = false;
        bool _positionChanged = false;

        private void UpdateHasChanged()
        {
            _page.SetHasChanges(_enabledChanged ||
                                _watermarkFileChanged ||
                                _transparencyChanged ||
                                _positionChanged);
        }

        internal void ResetHasChanges()
        {
            _enabledChanged = false;
            _watermarkFileChanged = false;
            _transparencyChanged = false;
            _positionChanged = false;
        }

        private void SetControlsEnabled( bool enabled )
        {
            _watermarkFile.Enabled = enabled;
            _transparencyTrackBar.Enabled = enabled;
            _watermarkGroupBox.Enabled = enabled;
            _watermarkLabel.Enabled = enabled;
            _positionComboBox.Enabled = enabled;
            _positionLabel.Enabled = enabled;
            _transparencyLabel.Enabled = enabled;
            _imageFileButton.Enabled = enabled;
        }

        private void EnableCheckedStateChanged(object sender, EventArgs e)
        {
            SetControlsEnabled(_enabledCheckBox.Checked);

            if (_page._bag != null)
            {
                _enabledChanged = (_enabledCheckBox.Checked != (bool)_page._bag[WatermarkModuleGlobals.Enabled]);
                UpdateHasChanged();
            }
        }

        private void FileButtonClicked(object sender, EventArgs e)
        {
            _openFileDialog.CheckFileExists = true;
            _openFileDialog.Filter = Resources.ImageFilter;
            _openFileDialog.ShowDialog();
        }

        private void FileSelected(object sender, CancelEventArgs e)
        {
            _watermarkFile.Text = _openFileDialog.FileName;
            if (_page._bag != null)
            {
                _watermarkFileChanged = (_watermarkFile.Text != (string)_page._bag[WatermarkModuleGlobals.WatermarkImage]);
                UpdateHasChanged();
            }
        }

        private void BarValueChanged(object sender, EventArgs e)
        {
            _transparencyTextBox.Text = _transparencyTrackBar.Value.ToString();
            if (_page._bag != null)
            {
                _transparencyChanged = (_transparencyTrackBar.Value != (int)_page._bag[WatermarkModuleGlobals.Transparency]);
                UpdateHasChanged();
            }
        }

        private void TransparencyTextChanged(object sender, EventArgs e)
        {
            int value = 50;

            if (Int32.TryParse(_transparencyTextBox.Text, out value) &&
                0 <= value &&
                value <= 100 )
            {
                _transparencyTrackBar.Value = value;
            }
            else
            {
                _transparencyTextBox.Text = _transparencyTrackBar.Value.ToString();
            }

            if (_page._bag != null)
            {
                _transparencyChanged = (_transparencyTrackBar.Value != (int)_page._bag[WatermarkModuleGlobals.Transparency]);
                UpdateHasChanged();
            }
        }


        private void PositionChanged(object sender, EventArgs e)
        {
            if (_page._bag != null)
            {
                _positionChanged = (((Position)_positionComboBox.SelectedValue) != ((Position)_page._bag[WatermarkModuleGlobals.Position]));
                UpdateHasChanged();
            }
        }

        private void FileTextChanged(object sender, EventArgs e)
        {
            if (_page._bag != null)
            {
                _watermarkFileChanged = (_watermarkFile.Text != (string)_page._bag[WatermarkModuleGlobals.WatermarkImage]);
                UpdateHasChanged();
            }
        }
    }
}
