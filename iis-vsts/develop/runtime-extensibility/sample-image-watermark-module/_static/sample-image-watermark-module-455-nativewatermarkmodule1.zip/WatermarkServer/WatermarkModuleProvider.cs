﻿//
// Copyright © Microsoft Corporation.  All rights reserved.
//

using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.Web.Management.Server;

namespace WatermarkServer
{
    public sealed class WatermarkModuleProvider : ConfigurationModuleProvider
    {
        protected override string ConfigurationSectionName
        {
            get {
                return "system.webServer/watermark";
            }
        }

        public override string FriendlyName
        {
            get
            {
                return Resources.FriendlyName;
            }
        }

        public override ModuleDefinition GetModuleDefinition(IManagementContext context)
        {
            if ((context != null) && !String.Equals(context.ClientUserInterfaceTechnology, "System.Windows.Forms.Control", StringComparison.OrdinalIgnoreCase))
            {
                return null;
            }

            ModuleDefinition moduleDefinition = new ModuleDefinition(Name, "WatermarkClient.WatermarkModule, watermarkclient, Version=1.0.0.0, Culture=neutral, PublicKeyToken=5f6f8f3f74d67fe4");

            return moduleDefinition;
        }

        public override Type ServiceType
        {
            get {
                return typeof(WatermarkModuleService);
            }
        }

        public override bool SupportsScope(ManagementScope scope)
        {
            return (scope == ManagementScope.Application) ||
                   (scope == ManagementScope.Site) ||
                   (scope == ManagementScope.Server);
        }
    }
}
