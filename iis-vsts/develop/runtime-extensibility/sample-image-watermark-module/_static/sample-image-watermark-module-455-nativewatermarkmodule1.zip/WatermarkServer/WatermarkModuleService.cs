﻿//
// Copyright © Microsoft Corporation.  All rights reserved.
//

using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.Web.Management.Server;

namespace WatermarkServer
{
    public sealed class WatermarkModuleService : ModuleService
    {
        internal WatermarkSection GetWatermarkSection()
        {
            WatermarkSection section = (WatermarkSection) ManagementUnit.Configuration.GetSection( "system.webServer/watermark", typeof( WatermarkSection ) );

            if (section == null)
            {
                RaiseException( Resources.ConfigurationError );
            }

            return section;
        }

        [ModuleServiceMethod(PassThrough = true)]
        public PropertyBag GetWatermarkSettings()
        {
            PropertyBag bag = new PropertyBag();

            WatermarkSection section = GetWatermarkSection();
    
            bag[WatermarkModuleGlobals.Enabled] = section.Enabled;
            bag[WatermarkModuleGlobals.WatermarkImage] = section.WatermarkImage;
            bag[WatermarkModuleGlobals.Transparency] = section.Transparency;
            bag[WatermarkModuleGlobals.Position] = section.Position;
            bag[WatermarkModuleGlobals.IsLocked] = section.IsLocked;

            return bag;
        }

        [ModuleServiceMethod(PassThrough = true)]
        public void UpdateWatermarkSettings( PropertyBag bag )
        {
            WatermarkSection section = GetWatermarkSection();
    
            section.Enabled = (bool) bag[WatermarkModuleGlobals.Enabled];
            section.WatermarkImage = (string) bag[WatermarkModuleGlobals.WatermarkImage];
            section.Transparency = (int) bag[WatermarkModuleGlobals.Transparency];
            section.Position = (Position) bag[WatermarkModuleGlobals.Position];

            ManagementUnit.ServerManager.CommitChanges();
        }

        
    }
}
