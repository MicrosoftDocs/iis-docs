//
// Copyright � Microsoft Corporation.  All rights reserved.
//

namespace WatermarkServer
{
    using System;
    using Microsoft.Web.Administration;
    
    
    internal class WatermarkSection : ConfigurationSection {
        
        public WatermarkSection() {
        }
        
        public bool Enabled {
            get {
                return ((bool)(base["enabled"]));
            }
            set {
                base["enabled"] = value;
            }
        }
        
        public Position Position {
            get {
                return ((Position)(base["position"]));
            }
            set {
                base["position"] = ((int)(value));
            }
        }
        
        public int Transparency {
            get {
                return ((int)(( (long) (base["transparency"])) & 0x8FFFFFFF ));
            }
            set {
                base["transparency"] = value;
            }
        }
        
        public string WatermarkImage {
            get {
                return ((string)(base["watermarkImage"]));
            }
            set {
                base["watermarkImage"] = value;
            }
        }
    }
}
