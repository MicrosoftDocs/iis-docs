Welcome to the Watermark Module sample code.  This is a native IIS 7 module that allows one
to automatically watermark any .jpg, .gif, and .png image file as it is being served by
your IIS 7 application.  There are several options as to the position of the watermark image
(i.e. top left, top right, bottom left, bottom right, center, stretch and tile).  It also
provides the ability to change the transparency of the watermark.

To start using this, first compile the module from this VS project.  You may also use the
precompiled versions in the "bin" directory.

NOTE: If compiling the project, you may have to update the post-build step where the project
      will run "gacutil" to add the compiled assembly to the global assembly cache.  The path
      to the executable may have to be updated to reflect your particular installation.

Next, to setup the module configuration, please do the following steps:

1.  Copy the "Watermark.dll" module to a known location (i.e. "c:\Watermark").
2.  Copy the "Watermark\Watermark.xml" file to "%windir%\system32\inetsrv\config\schema" directory.
3.  Add the following to the "%windir%\system32\inetsrv\config\applicationhost.config" file:

In the sectionGroup for "system.webServer", add the section definition:

            <section name="Watermark" overrideModeDefault="Allow" />

4.  In the "system.webServer/globalModules" section, add the following global module (modify
    the directory name as needed):

            <add name="WatermarkModule" image="c:\Watermark\Watermark.dll" />

5.  In the "system.webServer/modules" section, add the following line:

                <add name="WatermarkModule" />

6.  Next, use the "gacutil" command to put the IIS manager modules in the GAC, so that the 
    UI config modules are registered:

    gacutil /i WatermarkServer.dll
    gacutil /i WatermarkClient.dll

7.  Next, you must add them to the IIS manager configuration, in the
    "%windir%\system32\inetsrv\config\administration.config" file:

In the <moduleProviders> collection, add the following entry:

        <add name="Watermark" type="WatermarkServer.WatermarkModuleProvider, Watermarkserver, Version=1.0.0.0, Culture=neutral, PublicKeyToken=5f6f8f3f74d67fe4" />

And add the following line to the <modules> collection:

        <add name="Watermark" />


8. That's it.  You should now be able to configured the module via the UI and use the native module.

CAVEATS: The module currently does NOT change the ETAG or any other caching related headers
         in the response.  This means that if you're testing/using a browser that caches
         images, changes in the watermark module's config (i.e. change of image, image position, etc)
         will NOT cause a refresh of the already cached image.  A typical behavior of this is
         getting a watermarked image, making a config change and hitting "Refresh" in the browser
         and seeing the same image (now cached by the browser).  To resolve this, you should 
         delete and cached or temporary files from your browser.

         There are ways to resolve this properly, including modifying the ETAG value to reflect the
         current watermark config and responding properly to client browser "cache up-to-date" requests.
         These changes, though, are left as exercises for the community.



