﻿namespace ControlPanel {
    using System;
    using System.Collections.Generic;
    using System.Collections.ObjectModel;
    using System.IO;
    using System.Linq;
    using System.Net;
    using System.Security.Cryptography;
    using System.Web;
    using System.Configuration;
    using Microsoft.Web.Deployment;
    using Microsoft.Web.PlatformInstaller;
    using System.Runtime.InteropServices;
    using System.Diagnostics;

    public class Package {
        // Only download the ZIP file once and keep it handy
        private string _downloadTempFile;
        private readonly object _downloadTempFileLock = new object();

        // Parameters, which are lazy-loaded from the ZIP file
        private List<DeploymentSyncParameter> _parameters;
        private readonly object _parametersLock = new object();

        // TODO: Remove setters and use constructor?

        /// <summary>
        /// Gets or sets the description.
        /// </summary>
        public string Description { get; set; }

        /// <summary>
        /// Gets or sets the SHA1 hash of the download file.
        /// </summary>
        public string DownloadHash { get; set; }

        /// <summary>
        /// Gets or sets the download URL.
        /// </summary>
        public string DownloadUrl { get; set; }

        /// <summary>
        /// Gets or sets the package ID.
        /// </summary>
        public string ID { get; set; }

        /// <summary>
        /// Gets the package's parameters.
        /// </summary>
        public ReadOnlyCollection<PackageParameter> Parameters {
            get {
                Initialize();

                return new ReadOnlyCollection<PackageParameter>(
                    (from syncParam in _parameters
                     select new PackageParameter {
                         Name = syncParam.Name,
                         Description = syncParam.Description,
                         Value = syncParam.DefaultValue,
                         IsPassword = IsPassword(syncParam),
                         IsBoolean = IsBoolean(syncParam),
                         ValidationValues = SplitValidationValues(syncParam),
                         AllowEmpty = AllowEmpty(syncParam),
                         RegEx = HasRegEx(syncParam) ? syncParam.Validation.ValidationString : null // if there is no RegEx, allow any value
                     }).ToArray());
            }
        }

        /// <summary>
        /// Gets or sets the start page.
        /// </summary>
        public string StartPage { get; set; }

        /// <summary>
        /// Gets or sets the title.
        /// </summary>
        public string Title { get; set; }

        /// <summary>
        /// Gets or sets the version.
        /// </summary>
        public string Version { get; set; }

        private string GetDownload() {
            // If the download URL is a local file, just use it
            if (DownloadUrl.StartsWith("~/", StringComparison.Ordinal)) {
                return HttpContext.Current.Server.MapPath(DownloadUrl);
            }

            lock (_downloadTempFileLock) {
                if (_downloadTempFile == null) {
                    if (String.IsNullOrEmpty(DownloadHash)) {
                        throw new InvalidOperationException("The feed is missing the MD5 hash for this download.");
                    }

                    _downloadTempFile = Path.Combine(Path.GetTempPath(), "CPanelDownload-" + ID + ".zip");

                    // Download the file to the temp directory
                    WebClient webClient = new WebClient();
                    // This header is needed to identify the user-agent with the download server
                    webClient.Headers.Add("user-agent", "PI-Integrator/2.0.0.0(" + Environment.OSVersion.VersionString + ")");
                    webClient.DownloadFile(DownloadUrl, _downloadTempFile);

                    // Verify sha1 Hash
                    SHA1 sha1 = SHA1.Create();
                    byte[] hash = sha1.ComputeHash(File.ReadAllBytes(_downloadTempFile));
                    string hashString = hash.Aggregate("", (acc, value) => acc + value.ToString("X2"));

                    if (DownloadHash.ToUpperInvariant() != hashString) {
                        File.Delete(_downloadTempFile);
                        _downloadTempFile = null;

                        throw new InvalidOperationException("The download file appears to be corrupt.");
                    }
                }
            }

            return _downloadTempFile;
        }

        public string GetMissingRequirements() {
            string displayString = String.Empty;

            try {
                ProductManager pm = new ProductManager();

                // we need to load the whole product list since app will depend on products in that file
                // the "true" parameter says filter the installer set to only installers available on this
                // architecture
                pm.Load(new Uri(ConfigurationManager.AppSettings["PLFeedXmlUrl"]), true);

                Product p = pm.GetProduct(ID);
                ICollection<Product> missingProducts = p.GetMissingDependencies(null);
                if (missingProducts.Count > 0) {
                    displayString = "The server is missing the following products that are required to run this app: ";
                    foreach (Product missing in missingProducts) {
                        displayString += " " + missing.Title + ",";
                    }
                    displayString = displayString.Trim(',');
                }
            }
            catch {
            }

            return displayString;
        }

        private void Initialize() {
            lock (_parametersLock) {
                if (_parameters == null) {
                    LoadParameters();
                }
            }
        }

        public string Install(string siteName, string userName, string password, ReadOnlyCollection<PackageParameter> updatedValues) {
            Initialize();

            // TODO: Should the computer name be an editable field?
            // change localhost to a computer name to do remote deployments
            string agentUri = "https://localhost:8172/msdeploy.axd?Site=" + Uri.EscapeDataString(siteName);

            DeploymentBaseOptions sourceOptions = new DeploymentBaseOptions();

            // TODO: should show UI to the user asking them to choose between SQL and MYSQL
            sourceOptions.SkipDirectives.Add(new DeploymentSkipDirective("skipSqlDirective", "objectName=dbFullSql"));
            DeploymentProviderOptions providerOptions = new DeploymentProviderOptions(DeploymentWellKnownProvider.Package);
            providerOptions.Path = GetDownload();

            using (DeploymentObject iisApplication = DeploymentManager.CreateObject(providerOptions, sourceOptions)) {
                DeploymentBaseOptions destinationOptions = new DeploymentBaseOptions {
                    ComputerName = agentUri,
                    UserName = userName,
                    Password = password,
                    AuthenticationType = "basic",
                };

                // for each parameter that was specified in the UI, set its value 
                foreach (PackageParameter updatedValue in updatedValues) {
                    DeploymentSyncParameter parameter;

                    if (String.IsNullOrEmpty(updatedValue.Name)) {
                        throw new InvalidOperationException("A value without a name was passed to the installer");
                    }

                    // First verify that the parameter exists in the package and
                    // initialize it with the original content
                    if (!iisApplication.SyncParameters.TryGetValue(updatedValue.Name, out parameter)) {
                        throw new InvalidOperationException("Could not find a parameter with the name " + updatedValue.Name);
                    }

                    // Now set the value entered in the UI
                    if (updatedValue.IsBoolean)
                        parameter.Value = updatedValue.Boolean ? "true" : "false";
                    else if (!String.IsNullOrEmpty(updatedValue.SelectedValue))
                        parameter.Value = updatedValue.SelectedValue;
                    else
                        parameter.Value = updatedValue.Value;
                }

                string applicationPath = null;

                // there may be a bunch of hidden parameters that never got set.
                // set these to their default values (which will probably be calculated based on the other
                // parameters that were set).
                foreach (DeploymentSyncParameter parameter in iisApplication.SyncParameters) {
                    if (parameter.Value == null) {
                        throw new InvalidOperationException("Parameter '" + parameter.Name + "' value was not set. This indicates an issue with the package itself. Contact your system administrator.");
                    }

                    if (IsApplicationPath(parameter)) {
                        applicationPath = parameter.Value;
                    }
                }

                // Install the application
                DeploymentSyncOptions syncOptions = new DeploymentSyncOptions();
                iisApplication.SyncTo(DeploymentWellKnownProvider.Auto, String.Empty, destinationOptions, syncOptions);

                return applicationPath;
            }
        }

        private bool IsApplicationPath(DeploymentSyncParameter parameter) {
            return SplitTagsToUppercase(parameter).Any(t => t == "IISAPP");
        }

        private bool IsHidden(DeploymentSyncParameter parameter) {
            return SplitTagsToUppercase(parameter).Any(t => t == "HIDDEN");
        }

        private bool IsPassword(DeploymentSyncParameter parameter) {
            return SplitTagsToUppercase(parameter).Any(t => t == "PASSWORD");
        }

        private bool IsBoolean(DeploymentSyncParameter parameter)
        {
            if (parameter.Validation == null)
                return false;
            return (parameter.Validation.Kind & DeploymentSyncParameterValidationKind.Boolean) == DeploymentSyncParameterValidationKind.Boolean;
        }

        private bool HasRegEx(DeploymentSyncParameter parameter)
        {
            if (parameter.Validation == null)
                return false;
            return (parameter.Validation.Kind & DeploymentSyncParameterValidationKind.RegularExpression) == DeploymentSyncParameterValidationKind.RegularExpression;
        }

        private bool AllowEmpty(DeploymentSyncParameter parameter)
        {
            if (parameter.Validation == null)
                return false;
            return (parameter.Validation.Kind & DeploymentSyncParameterValidationKind.AllowEmpty) == DeploymentSyncParameterValidationKind.AllowEmpty;
        }

        private void LoadParameters() {
            string zipFile = GetDownload();

            if (!File.Exists(zipFile)) {
                throw new InvalidOperationException("Could not download package for ID=" + ID + ", Title=" + Title);
            }

            using (DeploymentObject iisApplication = DeploymentManager.CreateObject(DeploymentWellKnownProvider.Package, zipFile)) {
                _parameters = (from parameter in iisApplication.SyncParameters
                               where !IsHidden(parameter)
                               select parameter).ToList();
            }
        }

        private static string[] SplitTagsToUppercase(DeploymentSyncParameter parameter) {
            if (parameter.Tags == null)
                return new string[0];

            return parameter.Tags.ToUpperInvariant().Split(new[] { ',', ' ' }, StringSplitOptions.RemoveEmptyEntries);
        }

        private static string[] SplitValidationValues(DeploymentSyncParameter parameter)
        {
            if (parameter.Validation.ValidationString == null)
                return new string[0];

            return parameter.Validation.ValidationString.Split(new[] { ',', ' ' }, StringSplitOptions.None);
        }
    }
}
