﻿namespace ControlPanel {
    public class PackageParameter {
        /// <summary>
        /// Gets or sets the parameter description.
        /// </summary>
        public string Description { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether this parameter is a password.
        /// </summary>
        public bool IsPassword { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether this parameter is a boolean.
        /// </summary>
        public bool IsBoolean { get; set; }

        /// <summary>
        /// Gets or sets the boolean value.
        /// </summary>
        public bool Boolean { get; set; }

        /// <summary>
        /// Gets or sets the Allow Empty value.
        /// </summary>
        public bool AllowEmpty { get; set; }

        /// <summary>
        /// Gets or sets the parameter name.
        /// </summary>
        public string Name { get; set; }

        /// <summary>
        /// Gets or sets the parameter value.
        /// </summary>
        public string Value { get; set; }

        /// <summary>
        /// Gets or sets the validation values for this parameter.
        /// </summary>
        public string[] ValidationValues { get; set; }

        /// <summary>
        /// Gets or sets the selected validation value for this parameter.
        /// </summary>
        public string SelectedValue { get; set; }

        /// <summary>
        /// Gets or sets the RegEx validation value for this parameter.
        /// </summary>
        public string RegEx { get; set; }
    }
}