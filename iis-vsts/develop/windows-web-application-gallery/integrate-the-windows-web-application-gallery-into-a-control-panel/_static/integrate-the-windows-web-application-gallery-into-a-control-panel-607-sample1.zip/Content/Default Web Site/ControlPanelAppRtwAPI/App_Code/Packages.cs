﻿namespace ControlPanel {
    using System;
    using System.Collections.Generic;
    using System.Configuration;
    using System.Diagnostics.CodeAnalysis;
    using System.IO;
    using System.Net;
    using System.Web;
    using System.Xml;
    using Microsoft.Web.PlatformInstaller;

    public static class Packages {
        // Packages, which are lazy-loaded from the feed XML
        private static Dictionary<string, Package> _packages;
        private static readonly object _packagesLock = new object();

        /// <summary>
        /// Gets the package for a given package ID.
        /// </summary>
        /// <param name="id">The package ID</param>
        /// <returns>The package, if found; null otherwise.</returns>
        public static Package GetPackageById(string id) {
            lock (_packagesLock) {
                Initialize();

                Package result;
                _packages.TryGetValue(id, out result);
                return result;
            }
        }

        /// <summary>
        /// Gets all available packages.
        /// </summary>
        /// <returns>The package list</returns>
        [SuppressMessage("Microsoft.Design", "CA1024", Justification = "Symmetrical with GetPackageById, should not be a property")]
        public static IEnumerable<Package> GetPackages() {
            lock (_packagesLock) {
                Initialize();

                return _packages.Values;
            }
        }

        private static string GetXmlLocationFromFeed(string feedUrl) {
            // If the feed is local, just read it directly
            if (feedUrl.StartsWith("~/", StringComparison.Ordinal)) {
                return HttpContext.Current.Server.MapPath(feedUrl);
            }

            string tempFile = null;

            try {
                // Download the feed and read it
                tempFile = Path.GetTempFileName();
                WebClient webClient = new WebClient();
                webClient.DownloadFile(feedUrl, tempFile);
            }
            catch {
            }

            return tempFile;
        }

        private static void Initialize() {
            if (_packages == null) {
                Reload();
            }
        }

        public static void Reload() {
            lock (_packagesLock) {
                string feedUrl = ConfigurationManager.AppSettings["PLFeedXmlUrl"];// FeedXmlUrl
                if (String.IsNullOrEmpty(feedUrl)) {
                    throw new InvalidOperationException("Could not find FeedXmlUrl in application settings");
                }

                _packages = new Dictionary<string, Package>();

                // Parse the XML feed with the packages in them
                string fileLocation = GetXmlLocationFromFeed(feedUrl);
                if (!String.IsNullOrEmpty(fileLocation)) {
                    ProductManager pm = new ProductManager();

                    pm.Load(new Uri(fileLocation));

                    // if we were looking for non-app products we'd filter based on the OS here
                    // but they're all available for installation on any webserver OS (AFAIK)

                    Language english = pm.GetLanguage("en");            
                    foreach (Product p in pm.Products) {
                        if (!p.IsApplication) {
                            continue;
                        }

                        Installer installer = p.GetInstaller(english);

                        if (installer == null) {
                            // rare case but check if they have non-english installers
                            // and no english installer
                            if (p.Installers.Count > 0) {
                                installer = p.Installers[0];
                            }
                            else {
                                // some products are just for detection
                                continue;
                            }
                        }

                        // if there's no install location we'll skip as well
                        if (installer.InstallerFile == null) {
                            continue;
                        }


                        Package package = new Package {
                            ID = p.ProductId,
                            Description = p.Summary,
                            Title = p.Title,
                            Version = p.Version,
                            StartPage = installer.MSDeployPackage.StartPage ?? String.Empty,
                            DownloadUrl = installer.InstallerFile.InstallerUrl.AbsoluteUri,
                            DownloadHash = installer.InstallerFile.SHA1Hash
                        };

                        _packages.Add(package.ID, package);
                    }
                }
            }
        }
    }
}
