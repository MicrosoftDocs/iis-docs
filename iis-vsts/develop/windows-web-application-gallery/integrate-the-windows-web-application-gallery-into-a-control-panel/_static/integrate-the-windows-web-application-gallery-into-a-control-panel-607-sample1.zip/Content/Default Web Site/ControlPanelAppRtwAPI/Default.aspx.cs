﻿namespace ControlPanel {
    using System;
    using System.Web.UI;
    using System.Web.UI.WebControls;

    public partial class Default : Page {
        protected void Page_Init(object sender, EventArgs e) {
            PackageRepeater.DataSource = Packages.GetPackages();
            PackageRepeater.DataBind();
        }

        protected void PackageRepeater_ItemDataBound(object sender, RepeaterItemEventArgs e) {
            if (e.Item.ItemType != ListItemType.Item && e.Item.ItemType != ListItemType.AlternatingItem) {
                return;
            }

            // Set the link and description based on the values in the package
            Package package = (Package)e.Item.DataItem;
            HyperLink installLink = (HyperLink)e.Item.FindControl("InstallLink");
            installLink.NavigateUrl = "Install.aspx?id=" + Server.UrlEncode(package.ID);
            installLink.Text = Server.HtmlEncode(package.Title);
        }

        protected void ReloadButton_Click(object sender, EventArgs e) {
            Packages.Reload();

            Response.Redirect("Default.aspx");
        }
    }
}
