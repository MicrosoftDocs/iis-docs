﻿namespace ControlPanel {
    using System;
    using System.Collections.Generic;
    using System.Collections.ObjectModel;
    using System.Collections.Specialized;
    using System.Globalization;
    using System.Linq;
    using System.Web.UI;
    using System.Web.UI.WebControls;
    using Microsoft.Web.Deployment;
    using Microsoft.Web.Delegation;

    public partial class Install : Page {
        Package _package;

        protected void Page_Init() {
            try {
                // User must supply the ID on the URL
                string id = Request["id"];
                if (id == null) {
                    Response.Redirect("Default.aspx");
                }

                // If the package doesn't exist, send them back to the package list
                _package = Packages.GetPackageById(id);
                if (_package == null) {
                    Response.Redirect("Default.aspx");
                }

                // If the server is missing required products, display the error
                string missingRequirements = _package.GetMissingRequirements();
                if (!String.IsNullOrEmpty(missingRequirements)) {
                    ErrorText.Text = missingRequirements;
                    ErrorPanel.Visible = true;
                    ParameterPanel.Visible = false;
                    return;
                }

                TitleText.Text = Server.HtmlEncode(_package.Title);
                VersionText.Text = Server.HtmlEncode(_package.Version);

                ParameterList.DataSource = _package.Parameters;
                ParameterList.DataBind();

                ServerList.DataSource = new[] { new { SiteName = "", Username = "", Password = "" } };
                ServerList.DataBind();
            }
            catch (InvalidOperationException ex) {
                DisplayError(ex);
                ParameterPanel.Visible = false;
            }
            catch (DeploymentException ex) {
                DisplayError(ex);
                ParameterPanel.Visible = false;
            }
        }

        protected void InstallButton_Click(object sender, EventArgs e) {
            if (!IsValid) {
                return;
            }

            try {
                // Get the list of known package parameters
                ReadOnlyCollection<PackageParameter> packageParameters = _package.Parameters;

                // Store a list of updated values for installation
                List<PackageParameter> updatedValues = new List<PackageParameter>();

                foreach (ListViewItem item in ParameterList.Items) {
                    if (item.ItemType == ListViewItemType.DataItem) {
                        OrderedDictionary parameterListDictionary = new OrderedDictionary();
                        ParameterList.ExtractItemValues(parameterListDictionary, item, false);

                        // Workaround for getting the dropdownlist selected value, 
                        // "Bind" does not work in the markup.
                        DropDownList valueDropDownList = (DropDownList)item.FindControl("ValueDropDownList");
                        string selection = null;
                        if (valueDropDownList.Visible)
                            selection = valueDropDownList.SelectedValue;
                        //

                        PackageParameter packageParameter = new PackageParameter {
                            Name = (string)parameterListDictionary["Name"],
                            Value = (string)parameterListDictionary["Value"],
                            SelectedValue = selection,
                            IsBoolean = (bool)parameterListDictionary["IsBoolean"],
                            Boolean = (bool)parameterListDictionary["Boolean"],
                            RegEx = (string)parameterListDictionary["RegEx"]
                        };

                        // Ensure the user only posts values back for editable package parameters
                        if (!packageParameters.Any(pp => pp.Name == packageParameter.Name)) {
                            throw new InvalidOperationException("The request appears to be malformed. Please try the request again.");
                        }

                        updatedValues.Add(packageParameter);
                    }
                }

                OrderedDictionary serverListDictionary = new OrderedDictionary();
                ServerList.ExtractItemValues(serverListDictionary, ServerList.Items[0], false);

                // Install the package
                _package.Install((string)serverListDictionary["SiteName"],
                                 (string)serverListDictionary["Username"],
                                 (string)serverListDictionary["Password"],
                                 new ReadOnlyCollection<PackageParameter>(updatedValues));

                // Show the success message
                ErrorPanel.Visible = false;
                ParameterPanel.Visible = false;
                SuccessPanel.Visible = true;
            }
            catch (InvalidOperationException ex) {
                DisplayError(ex);
            }
            catch (DeploymentException ex) {
                DisplayError(ex);
            }
        }

        private void DisplayError(Exception ex) {
            string message = Server.HtmlEncode(ex.Message);

            // Only show a stack trace when custom errors are off (by default, for localhost requests only)
            if (!Context.IsCustomErrorEnabled) {
                message += String.Format(CultureInfo.InvariantCulture, "<pre>{0}</pre>", Server.HtmlEncode(ex.ToString()));
            }

            ErrorText.Text = message;
            ErrorPanel.Visible = true;
        }

        protected void ParameterList_OnItemDataBound(object sender, ListViewItemEventArgs e) {
            if (e.Item.ItemType == ListViewItemType.DataItem)
            {
                ListViewDataItem listViewDataItem = (ListViewDataItem)e.Item;
                PackageParameter parameter = (PackageParameter)listViewDataItem.DataItem;

                // If the parameter is a password, we want the text box to hide their input values
                if (parameter.IsPassword)
                {
                    TextBox valueTextBox = (TextBox)e.Item.FindControl("ValueTextBox");
                    valueTextBox.TextMode = TextBoxMode.Password;
                }
                // If the parameter is a boolean, we want to use the checkbox control
                else if (parameter.IsBoolean)
                {
                    CheckBox valueCheckBox = (CheckBox)e.Item.FindControl("ValueCheckBox");
                    valueCheckBox.Visible = true;
                    TextBox valueTextBox = (TextBox)e.Item.FindControl("ValueTextBox");
                    valueTextBox.Visible = false;
                    RequiredFieldValidator validator = (RequiredFieldValidator)e.Item.FindControl("RequiredFieldValidator");
                    validator.Enabled = false;
                    RegularExpressionValidator validatorRegEx = (RegularExpressionValidator)e.Item.FindControl("RegExValidator");
                    validatorRegEx.Enabled = false;
                }
                // If the parameter is an enumeration, we want to use the dropdownlist control
                else if (parameter.ValidationValues.Count() != 0)
                {
                    DropDownList valueDropdownlist = (DropDownList)e.Item.FindControl("ValueDropDownList");
                    valueDropdownlist.Visible = true;
                    valueDropdownlist.DataSource = parameter.ValidationValues;
                    TextBox valueTextBox = (TextBox)e.Item.FindControl("ValueTextBox");
                    valueTextBox.Visible = false;
                    RequiredFieldValidator validator = (RequiredFieldValidator)e.Item.FindControl("RequiredFieldValidator");
                    validator.Enabled = false;
                    RegularExpressionValidator validatorRegEx = (RegularExpressionValidator)e.Item.FindControl("RegExValidator");
                    validatorRegEx.Enabled = false;

                    // If the parameter allows empty values add the empty element to the list
                    if (parameter.AllowEmpty)
                    {
                        ListItem EmptyItem = new ListItem("");
                        valueDropdownlist.Items.Add(EmptyItem);
                    }
                }
                // If the parameter has a RegEx validation string and also allows empty value change the ValidationExpression to include empty values
                if (!string.IsNullOrEmpty(parameter.RegEx) && parameter.AllowEmpty)
                {
                    RegularExpressionValidator validatorRegEx = (RegularExpressionValidator)e.Item.FindControl("RegExValidator");
                    validatorRegEx.ValidationExpression = validatorRegEx.ValidationExpression + "|.*";
                }
            }
        }
    }
}
