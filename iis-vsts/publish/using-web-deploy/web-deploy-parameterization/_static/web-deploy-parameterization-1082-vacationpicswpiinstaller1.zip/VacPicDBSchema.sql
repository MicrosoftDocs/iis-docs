SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[webpages_Roles](
	[RoleId] [int] IDENTITY(1,1) NOT NULL,
	[RoleName] [nvarchar](256) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
 CONSTRAINT [webpages_Roles_PK__webpages_Roles__0000000000000090] PRIMARY KEY CLUSTERED 
(
	[RoleId] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON),
 CONSTRAINT [webpages_Roles_UQ__webpages_Roles__0000000000000095] UNIQUE NONCLUSTERED 
(
	[RoleName] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
)

GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[webpages_Membership](
	[UserId] [int] NOT NULL,
	[CreateDate] [datetime] NULL,
	[ConfirmationToken] [nvarchar](128) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[IsConfirmed] [bit] NULL,
	[LastPasswordFailureDate] [datetime] NULL,
	[PasswordFailuresSinceLastSuccess] [int] NOT NULL,
	[Password] [nvarchar](128) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
	[PasswordChangedDate] [datetime] NULL,
	[PasswordSalt] [nvarchar](128) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
	[PasswordVerificationToken] [nvarchar](128) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[PasswordVerificationTokenExpirationDate] [datetime] NULL,
 CONSTRAINT [webpages_Membership_PK__webpages_Membership__0000000000000086] PRIMARY KEY CLUSTERED 
(
	[UserId] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
)

GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[UserProfiles](
	[Bio] [nvarchar](4000) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[DisplayName] [nvarchar](4000) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[Email] [nvarchar](4000) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[UserId] [int] IDENTITY(1,1) NOT NULL,
 CONSTRAINT [UserProfiles_PK__UserProfiles__0000000000000036] PRIMARY KEY CLUSTERED 
(
	[UserId] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
)

GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Tags](
	[TagName] [nvarchar](128) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
 CONSTRAINT [Tags_PK__Tags__0000000000000052] PRIMARY KEY CLUSTERED 
(
	[TagName] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
)

GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Galleries](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[Name] [nvarchar](4000) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
 CONSTRAINT [Galleries_PK__Galleries__0000000000000040] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
)

GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[webpages_UsersInRoles](
	[UserId] [int] NOT NULL,
	[RoleId] [int] NOT NULL,
 CONSTRAINT [webpages_UsersInRoles_PK__webpages_UsersInRoles__000000000000009F] PRIMARY KEY CLUSTERED 
(
	[UserId] ASC,
	[RoleId] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
)

GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Photos](
	[ContentType] [nvarchar](4000) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[Description] [nvarchar](4000) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[FileContents] [image] NULL,
	[FileExtension] [nvarchar](4000) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[FileSize] [int] NOT NULL,
	[FileTitle] [nvarchar](4000) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
	[GalleryId] [int] NOT NULL,
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[ModifiedFileContents] [image] NULL,
	[UploadDate] [datetime] NOT NULL,
	[UserId] [int] NULL,
 CONSTRAINT [Photos_PK__Photos__0000000000000028] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
)

GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Comments](
	[CommentDate] [datetime] NOT NULL,
	[CommentText] [nvarchar](4000) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[PhotoId] [int] NULL,
	[UserId] [int] NULL,
 CONSTRAINT [Comments_PK__Comments__000000000000000C] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
)

GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Photos_Tags](
	[Photos_Id] [int] NOT NULL,
	[Tags_TagName] [nvarchar](128) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
 CONSTRAINT [Photos_Tags_PK__Photos_Tags__000000000000004A] PRIMARY KEY CLUSTERED 
(
	[Photos_Id] ASC,
	[Tags_TagName] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
)

GO
ALTER TABLE [dbo].[webpages_Membership] ADD  CONSTRAINT [DF_webpages_Membership_IsConfirmed]  DEFAULT ((0)) FOR [IsConfirmed]
GO
ALTER TABLE [dbo].[webpages_Membership] ADD  CONSTRAINT [DF_webpages_Membership_PasswordFailuresSinceLastSuccess]  DEFAULT ((0)) FOR [PasswordFailuresSinceLastSuccess]
GO
ALTER TABLE [dbo].[webpages_UsersInRoles]  WITH CHECK ADD  CONSTRAINT [webpages_UsersInRoles_fk_RoleId] FOREIGN KEY([RoleId])
REFERENCES [dbo].[webpages_Roles] ([RoleId])
GO
ALTER TABLE [dbo].[webpages_UsersInRoles] CHECK CONSTRAINT [webpages_UsersInRoles_fk_RoleId]
GO
ALTER TABLE [dbo].[webpages_UsersInRoles]  WITH CHECK ADD  CONSTRAINT [webpages_UsersInRoles_fk_UserId] FOREIGN KEY([UserId])
REFERENCES [dbo].[UserProfiles] ([UserId])
GO
ALTER TABLE [dbo].[webpages_UsersInRoles] CHECK CONSTRAINT [webpages_UsersInRoles_fk_UserId]
GO
ALTER TABLE [dbo].[Photos]  WITH CHECK ADD  CONSTRAINT [Photos_FK_Photos_GalleryId_Galleries_Id] FOREIGN KEY([GalleryId])
REFERENCES [dbo].[Galleries] ([Id])
GO
ALTER TABLE [dbo].[Photos] CHECK CONSTRAINT [Photos_FK_Photos_GalleryId_Galleries_Id]
GO
ALTER TABLE [dbo].[Photos]  WITH CHECK ADD  CONSTRAINT [Photos_FK_Photos_UserId_UserProfiles_UserId] FOREIGN KEY([UserId])
REFERENCES [dbo].[UserProfiles] ([UserId])
GO
ALTER TABLE [dbo].[Photos] CHECK CONSTRAINT [Photos_FK_Photos_UserId_UserProfiles_UserId]
GO
ALTER TABLE [dbo].[Comments]  WITH CHECK ADD  CONSTRAINT [Comments_FK_Comments_PhotoId_Photos_Id] FOREIGN KEY([PhotoId])
REFERENCES [dbo].[Photos] ([Id])
GO
ALTER TABLE [dbo].[Comments] CHECK CONSTRAINT [Comments_FK_Comments_PhotoId_Photos_Id]
GO
ALTER TABLE [dbo].[Comments]  WITH CHECK ADD  CONSTRAINT [Comments_FK_Comments_UserId_UserProfiles_UserId] FOREIGN KEY([UserId])
REFERENCES [dbo].[UserProfiles] ([UserId])
GO
ALTER TABLE [dbo].[Comments] CHECK CONSTRAINT [Comments_FK_Comments_UserId_UserProfiles_UserId]
GO
ALTER TABLE [dbo].[Photos_Tags]  WITH CHECK ADD  CONSTRAINT [Photos_Tags_FK_Photos_Tags_Photos_Id_Photos_Id] FOREIGN KEY([Photos_Id])
REFERENCES [dbo].[Photos] ([Id])
GO
ALTER TABLE [dbo].[Photos_Tags] CHECK CONSTRAINT [Photos_Tags_FK_Photos_Tags_Photos_Id_Photos_Id]
GO
ALTER TABLE [dbo].[Photos_Tags]  WITH CHECK ADD  CONSTRAINT [Photos_Tags_FK_Photos_Tags_Tags_TagName_Tags_TagName] FOREIGN KEY([Tags_TagName])
REFERENCES [dbo].[Tags] ([TagName])
GO
ALTER TABLE [dbo].[Photos_Tags] CHECK CONSTRAINT [Photos_Tags_FK_Photos_Tags_Tags_TagName_Tags_TagName]
GO
