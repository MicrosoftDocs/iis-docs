var SOURCETYPES_NAMES_BUILTIN = "BuiltIn";
var SOURCETYPES_NAMES_MODULE = "Module";
var SOURCETYPES_NAMES_REQUEST_HEADER = "RequestHeader";
var SOURCETYPES_NAMES_RESPONSE_HEADER = "ResponseHeader";
var SOURCETYPES_NAMES_SERVER_VARIABLE = "ServerVariable";

var XLOG_CFGSECTION_SERVER_XPATH = "system.webServer/advancedLogging/server";

var ROOT_ADVANCED_LOGGING_NODE_NAME = "advancedLogging";
var ROOT_CLIENT_POST_XML_NAME = "XML";

var CFG_PATH_APPHOST = "MACHINE/WEBROOT/APPHOST";

var COLL_FIELDS_ELEMENT_NAME = "fields";			// server/fields
var COLL_LOG_DEFINITIONS_ELEMENT_NAME = "logDefinitions";	// server/logDefinitions
var COLL_SELECTED_FIELDS_ELEMENT_NAME = "selectedFields";	// server/logDefinitions/logDefinition/selectedFields

var COL_ITEM_FIELD_ELEMENT_NAME = "field";			// elementName for 'fields' collection
var COL_ITEM_LOG_DEFINITION_ELEMENT_NAME = "logDefinition";	// elementName for 'logDefinitions' collection
var COL_ITEM_LOG_FIELD_ELEMENT_NAME = "logField";		// elementName for 'selectedFields' collection

var COLL_LOG_DEFINITIONS_KEY = "baseFileName";
var COLL_LOG_DEFINITION_FIELDS_KEY = "id";
var COLL_FIELDS_KEY = "id";
var COLL_FIELDS_SOURCE_TYPE = "sourceType";
var COLL_FIELDS_SOURCE_NAME = "sourceName";

var DEFAULT_BASE_FILENAME = "%COMPUTERNAME%-Client";


var filepath = GetCommandLineParamater("f", "fields.xml");
WScript.Echo (" - Opening File: [" + filepath + "]");


var baseFilename = GetCommandLineParamater("b", DEFAULT_BASE_FILENAME);
var xPath = "//advancedLogging/fields/field";

var objXmlDoc = new ActiveXObject( "Microsoft.XMLDOM" );
objXmlDoc.async="false";
objXmlDoc.load( filepath );

var arrErrorNodes = new Array();
var arrErrors = new Array();



if (objXmlDoc.xml != "")
{
	var objXmlRootNode = objXmlDoc.documentElement;
	var objXmlNodeList = null;

	var clientXmlFile = false;
	switch (objXmlRootNode.nodeName)
	{
		case ROOT_ADVANCED_LOGGING_NODE_NAME:
			objXmlNodeList = objXmlRootNode.selectNodes(xPath);

			break;

		case ROOT_CLIENT_POST_XML_NAME:
//			WScript.Echo("In XML");
			objXmlNodeList = objXmlRootNode.childNodes;
			clientXmlFile = true;

			break;

	}
	var newFieldsCount = objXmlNodeList.length;

	// Open NativeReader to write to global config path (applicationhost.config)
	var objAdminManager = new ActiveXObject('Microsoft.ApplicationHost.WritableAdminManager');
	objAdminManager.CommitPath = CFG_PATH_APPHOST;
	var serverConfigSection = objAdminManager.GetAdminSection(XLOG_CFGSECTION_SERVER_XPATH, CFG_PATH_APPHOST);

	// Open the <fields> config collection
	var fieldsCollection = serverConfigSection.ChildElements.Item(COLL_FIELDS_ELEMENT_NAME).Collection;

	// Create new logDefinition
	var logDefinitionsCollection = serverConfigSection.ChildElements.Item(COLL_LOG_DEFINITIONS_ELEMENT_NAME).Collection;
	var newLogDefinition = logDefinitionsCollection.CreateNewElement(COL_ITEM_LOG_DEFINITION_ELEMENT_NAME);
	newLogDefinition.Properties.Item(COLL_LOG_DEFINITIONS_KEY).Value = baseFilename;
	newLogDefinition.Properties.Item("enabled").Value = false;		// disable by default...
	

	var selectedFieldsCollection = newLogDefinition.ChildElements.Item(COLL_SELECTED_FIELDS_ELEMENT_NAME).Collection;

	// Always add date/time to logdefinition...
	var serverFieldIds = new Array ("Date-UTC", "Time-UTC", "URI-Stem", "CPU-Utilization");
	var serverFieldsIdx = -999;
	for (serverFieldsIdx = 0; serverFieldsIdx < serverFieldIds.length; serverFieldsIdx++)
	{
		var serverFieldName = serverFieldIds[serverFieldsIdx];

		var serverField = selectedFieldsCollection.CreateNewElement(COL_ITEM_LOG_FIELD_ELEMENT_NAME);
		serverField.Properties.Item(COLL_LOG_DEFINITION_FIELDS_KEY).Value = serverFieldName;

		selectedFieldsCollection.AddElement(serverField);
	}

	var originalGlobalFieldsCount = fieldsCollection.count;
	var i = 0;
	for( i=0; i< newFieldsCount; i++)
	{
		var currentNode = objXmlNodeList[i];

		// Create a new <field> config collection item
		var newField = fieldsCollection.CreateNewElement(COL_ITEM_FIELD_ELEMENT_NAME);

	
		var fieldId = "--DEFAULTVALUE--";
		if (clientXmlFile == true)
		{
			fieldId = currentNode.nodeName;

			newField.Properties.Item(COLL_FIELDS_KEY).Value = fieldId;
			newField.Properties.Item(COLL_FIELDS_SOURCE_NAME).Value = fieldId;
			newField.Properties.Item(COLL_FIELDS_SOURCE_TYPE).Value = SOURCETYPES_NAMES_MODULE;
		}
		else
		{
			var j=0;
			for (j=0; j<currentNode.attributes.length; j++)
			{
				var currentAttribute = currentNode.attributes[j];
				newField.Properties.Item(currentAttribute.name).Value = currentAttribute.value;

				if (currentAttribute.name == COLL_FIELDS_KEY)
				{
					fieldId = currentAttribute.value;
				}
			}
		}

		try
		{
			// Add the new <field> to the <fields> collection...
			fieldsCollection.AddElement(newField);

			if (fieldId != "--DEFAULTVALUE--")
			{
				// Add new global field to logDefinition
				var newLogField = selectedFieldsCollection.CreateNewElement(COL_ITEM_LOG_FIELD_ELEMENT_NAME);
				newLogField.Properties.Item(COLL_LOG_DEFINITION_FIELDS_KEY).Value = fieldId;

				selectedFieldsCollection.AddElement(newLogField);		
			}
		}
		catch (addNewFieldError)
		{
			arrErrorNodes[arrErrorNodes.length] = currentNode.xml;
			arrErrors[arrErrors.length] = addNewFieldError.description;
			// WScript.Echo("  - ERROR:  Failed to add <field> - [" + addNewFieldError.description + "]");
			// WScript.Echo("       - Field: [" + currentNode.xml + "]");
		}
	}

	// Reporting
	var fieldsAdded = fieldsCollection.count - originalGlobalFieldsCount;
	var selectedFieldsCount = selectedFieldsCollection.count;

	if (selectedFieldsCount > 0)
	{
		logDefinitionsCollection.AddElement(newLogDefinition);
	}

	try
	{
		if ((fieldsAdded > 0) || (selectedFieldsCount > 0))
		{
			objAdminManager.CommitChanges();
		}

		WScript.Echo("");
		WScript.Echo("SUMMARY:");
		WScript.Echo("--------------------------------------------");
		WScript.Echo("  Fields found in '" + filepath + "': [" + newFieldsCount + "]");
		WScript.Echo("  Fields Added to global <fields> collection: [" + fieldsAdded + "]");
		if (selectedFieldsCount > 0)
		{
			WScript.Echo("  LogDefinition '" + baseFilename + "' successfully added with [" + selectedFieldsCount + "] fields...");
		}
		else
		{
			WScript.Echo("  LogDefinition '" + baseFilename + "' NOT added...");
		}

		if (arrErrorNodes.length > 0)
		{
			var errorFileName = "AddFieldsErrors.log";

			WScript.Echo("");
			WScript.Echo("  ERRORS:");
			WScript.Echo("      Fields not added to global <fields> collection: [" + (newFieldsCount - fieldsAdded) + "]");
			WScript.Echo("      Fields not added to logDefinition '" + baseFilename + "': [" + (serverFieldIds.length + newFieldsCount - selectedFieldsCount) + "]");
			WScript.Echo("");
			WScript.Echo("      Please see '" + errorFileName + "' for error details...");

			try
			{

				var FOR_WRITING = 2;
				var fsoErrors = new ActiveXObject( "Scripting.FileSystemObject" );
				var fileStream = fsoErrors.OpenTextFile(errorFileName, FOR_WRITING, true);

				var k=0;
				for(k=0; k<arrErrorNodes.length; k++)
				{
					// Write error to log file...
					fileStream.writeLine("Field Not Added " + k + ":");
					fileStream.writeLine("  xmlNode:  [" + arrErrorNodes[k] + "]");
					fileStream.writeLine("  Error:  [" + arrErrors[k] + "]");
					fileStream.writeBlankLines(2);
				}
				fileStream.Close();
//				fsoErrors.Close();
			}
			catch (errorFileException)
			{
				WScript.Echo("      *** ERROR writing '" + errorFileName + "': [" + errorFileException.description + "]");
			}
		}
	}
	catch (commitError)
	{
		WScript.Echo("ERROR:  Failed to commit changes - [" + commitError.description + "]");
	}
}
else
{
	WScript.Echo("ERROR:  Could not open file '" + filepath + "'");
}


function GetCommandLineParamater(parameterName, defaultValue)
{
	var returnValue = defaultValue;
	if (WScript.Arguments.Named.Exists(parameterName))
	{
		returnValue = WScript.Arguments.Named.Item(parameterName);
	}
	return returnValue;	
}