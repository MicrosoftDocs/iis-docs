﻿//------------------------------------------------------------------------------
// <copyright file="CanonicalDomainForm.Designer.cs" company="Microsoft">
//     Copyright (c) Microsoft Corporation.  All rights reserved.
// </copyright>
//------------------------------------------------------------------------------

namespace CanonicalDomainTemplate
{

    internal partial class CanonicalDomainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;
        private System.Windows.Forms.Button _OkButton;
        private System.Windows.Forms.Button _CancelButton;
        private System.Windows.Forms.TextBox _DomainTextBox;
        private System.Windows.Forms.Label _DescriptionLabel;
        private System.Windows.Forms.Label _ExampleLabel;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this._OkButton = new System.Windows.Forms.Button();
            this._CancelButton = new System.Windows.Forms.Button();
            this._DomainTextBox = new System.Windows.Forms.TextBox();
            this._DescriptionLabel = new System.Windows.Forms.Label();
            this._ExampleLabel = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // _OkButton
            // 
            this._OkButton.DialogResult = System.Windows.Forms.DialogResult.OK;
            this._OkButton.Location = new System.Drawing.Point(202, 131);
            this._OkButton.Name = "_OkButton";
            this._OkButton.Size = new System.Drawing.Size(75, 23);
            this._OkButton.TabIndex = 0;
            this._OkButton.Text = "Ok";
            this._OkButton.UseVisualStyleBackColor = true;
            this._OkButton.Click += new System.EventHandler(this.OnOkButtonClick);
            // 
            // _CancelButton
            // 
            this._CancelButton.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this._CancelButton.Location = new System.Drawing.Point(285, 131);
            this._CancelButton.Name = "_CancelButton";
            this._CancelButton.Size = new System.Drawing.Size(75, 23);
            this._CancelButton.TabIndex = 1;
            this._CancelButton.Text = "Cancel";
            this._CancelButton.UseVisualStyleBackColor = true;
            // 
            // _DomainTextBox
            // 
            this._DomainTextBox.Location = new System.Drawing.Point(12, 53);
            this._DomainTextBox.Name = "_DomainTextBox";
            this._DomainTextBox.Size = new System.Drawing.Size(349, 20);
            this._DomainTextBox.TabIndex = 2;
            // 
            // _DescriptionLabel
            // 
            this._DescriptionLabel.AutoSize = true;
            this._DescriptionLabel.Location = new System.Drawing.Point(13, 34);
            this._DescriptionLabel.Name = "_DescriptionLabel";
            this._DescriptionLabel.Size = new System.Drawing.Size(276, 13);
            this._DescriptionLabel.TabIndex = 3;
            this._DescriptionLabel.Text = "Specify the domain that you want your site visitors to use:";
            // 
            // _ExampleLabel
            // 
            this._ExampleLabel.AutoSize = true;
            this._ExampleLabel.Location = new System.Drawing.Point(13, 80);
            this._ExampleLabel.Name = "_ExampleLabel";
            this._ExampleLabel.Size = new System.Drawing.Size(141, 13);
            this._ExampleLabel.TabIndex = 4;
            this._ExampleLabel.Text = "Example: www.contoso.com";
            // 
            // _CanonicalDomainForm
            // 
            this.AcceptButton = this._OkButton;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.CancelButton = this._CancelButton;
            this.ClientSize = new System.Drawing.Size(373, 168);
            this.Controls.Add(this._ExampleLabel);
            this.Controls.Add(this._DescriptionLabel);
            this.Controls.Add(this._DomainTextBox);
            this.Controls.Add(this._CancelButton);
            this.Controls.Add(this._OkButton);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "_CanonicalDomainForm";
            this.ShowInTaskbar = false;
            this.Text = "Canonical Domain Name";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

    }
}