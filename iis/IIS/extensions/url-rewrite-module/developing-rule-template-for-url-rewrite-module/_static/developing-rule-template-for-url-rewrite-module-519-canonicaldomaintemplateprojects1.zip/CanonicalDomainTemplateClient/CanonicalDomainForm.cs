﻿//------------------------------------------------------------------------------
// <copyright file="CanonicalDomainForm.cs" company="Microsoft">
//     Copyright (c) Microsoft Corporation.  All rights reserved.
// </copyright>
//------------------------------------------------------------------------------

using System;
using System.Windows.Forms;

namespace CanonicalDomainTemplate
{

    internal sealed partial class CanonicalDomainForm : Form
    {
        private CanonicalDomainModuleServiceProxy _serviceProxy;

        public CanonicalDomainForm(CanonicalDomainModuleServiceProxy serviceProxy)
        {
            _serviceProxy = serviceProxy;
            InitializeComponent();
        }

        private void GenerateRule(string domainName)
        {
            try
            {
                _serviceProxy.GenerateRule(domainName);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }         
        }

        private void OnOkButtonClick(object sender, EventArgs e)
        {
            GenerateRule(_DomainTextBox.Text);
        }

    }
}
