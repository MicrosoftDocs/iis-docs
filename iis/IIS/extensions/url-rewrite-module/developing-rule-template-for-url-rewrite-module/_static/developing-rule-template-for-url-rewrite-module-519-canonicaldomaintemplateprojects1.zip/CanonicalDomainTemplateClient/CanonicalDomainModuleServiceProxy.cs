//------------------------------------------------------------------------------
// <copyright file="CanonicalDomainModuleServiceProxy.cs" company="Microsoft">
//     Copyright (c) Microsoft Corporation.  All rights reserved.
// </copyright>
//------------------------------------------------------------------------------

using System;
using Microsoft.Web.Management.Client;

namespace CanonicalDomainTemplate
{

    internal sealed class CanonicalDomainModuleServiceProxy : ModuleServiceProxy
    {

        public void GenerateRule(string domainName)
        {
            Invoke("GenerateRule", domainName);
        }
    }
}
